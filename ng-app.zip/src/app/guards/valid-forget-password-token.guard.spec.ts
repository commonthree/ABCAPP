import { TestBed } from '@angular/core/testing';

import { ValidForgetPasswordTokenGuard } from './valid-forget-password-token.guard';

describe('ValidForgetPasswordTokenGuard', () => {
  let guard: ValidForgetPasswordTokenGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(ValidForgetPasswordTokenGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
