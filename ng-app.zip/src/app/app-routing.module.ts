import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { UserRoleComponent } from './components/user-role/user-role.component';
import { AuthGuard } from './guards/auth.guard';
import { ValidForgetPasswordTokenGuard } from './guards/valid-forget-password-token.guard';
import { TopHeaderLayoutComponent } from './layout/top-header-layout/top-header-layout.component';


const routes: Routes = [
  {
    path: '', component: TopHeaderLayoutComponent, canActivate: [AuthGuard],
    children: [
      { path: 'admins', loadChildren: () => import('./modules/admin/admin/admin.module').then(m => m.AdminModule) },
      { path: 'guardians', loadChildren: () => import('./modules/admin/guardian/guardian.module').then(m => m.GuardianModule) },
      { path: 'teachers', loadChildren: () => import('./modules/admin/teacher/teacher.module').then(m => m.TeacherModule) },
      { path: 'students', loadChildren: () => import('./modules/admin/student/student.module').then(m => m.StudentModule) },
      { path: 'courses', loadChildren: () => import('./modules/admin/course/course.module').then(m => m.CourseModule) },
      { path: 'userrole/:id', component: UserRoleComponent }
    ]
  },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'password/forgot', component: ForgetPasswordComponent },
  { path: 'password/reset/:token', component: ResetPasswordComponent, canActivate: [ValidForgetPasswordTokenGuard] },
  { path: 'true', loadChildren: () => import('./modules/guardian/guardian.module').then(m => m.GuardianModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
