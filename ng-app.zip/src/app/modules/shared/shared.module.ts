import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputMessageHelperComponent } from './components/input-message-helper/input-message-helper.component';
import { CommonModalComponent } from './components/common-modal/common-modal.component';
import { CommonHttpErrorModalComponent } from './components/common-http-error-modal/common-http-error-modal.component';
import { CommonInfoModalComponent } from './components/common-info-modal/common-info-modal.component';
import { UserStatusBadgeComponent } from './components/user-status-badge/user-status-badge.component';
import { SvgTextComponent } from './components/svg-text/svg-text.component';



@NgModule({
  declarations: [InputMessageHelperComponent, CommonModalComponent, CommonHttpErrorModalComponent, CommonInfoModalComponent,
    UserStatusBadgeComponent, SvgTextComponent],
  imports: [
    CommonModule
  ],
  exports: [InputMessageHelperComponent, UserStatusBadgeComponent, SvgTextComponent]
})
export class SharedModule { }
