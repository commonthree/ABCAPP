import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CommonHttpErrorModalComponent } from '../components/common-http-error-modal/common-http-error-modal.component';
import { CommonInfoModalComponent } from '../components/common-info-modal/common-info-modal.component';
import { CommonModalComponent } from '../components/common-modal/common-modal.component';

@Injectable({
  providedIn: 'root'
})
export class CommonModalService {

  constructor(private modalService: BsModalService) { }

  public showModal(title: string, message: string){
    return this.modalService.show(CommonModalComponent, {
      animated: true,
      initialState: {
        title: title,
        message: message
      }
    })
  }

  public showInfoModal(title, message): BsModalRef<CommonInfoModalComponent> {
    return this.modalService.show(CommonInfoModalComponent, {
      animated: true,
      class: 'text-info',
      initialState: {
        title: title,
        message: message
      }
    })
  }


  public showErrorModal(response: HttpErrorResponse): BsModalRef<CommonHttpErrorModalComponent> {
    return this.modalService.show(CommonHttpErrorModalComponent, {
      animated: true,
      class: 'text-danger',
      initialState: {
        response: response
      }
    })
  }

}
