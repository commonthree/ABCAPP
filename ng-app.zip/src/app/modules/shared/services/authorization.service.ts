import { Injectable } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {
  constructor(private authService: AuthenticationService) { }

  public onlyAdmin(){
    if(this.authService.authenticatedUser){
      let roles = this.authService.authenticatedUser.roles;
      return roles.includes('ADMIN') || roles.includes('SUPER_ADMIN');
    }
    return false;
  }

  public onlyAdminAndTeacher(){
    if(this.authService.authenticatedUser){
      let roles = this.authService.authenticatedUser.roles;
      return roles.includes('ADMIN') || roles.includes('SUPER_ADMIN') || roles.includes('TEACHER');
    }
    return false;
  }

  public onlyGuardian(){
    if(this.authService.authenticatedUser){
      let roles = this.authService.authenticatedUser.roles;
      return roles.includes('GUARDIAN');
    }
    return false;
  }

  public onlyStudent(){
    if(this.authService.authenticatedUser){
      let roles = this.authService.authenticatedUser.roles;
      return roles.includes('STUDENT');
    }
    return false;
  }
}
