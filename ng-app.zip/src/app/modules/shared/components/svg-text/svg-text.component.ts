import { Component, HostBinding, OnInit } from '@angular/core';

@Component({
  selector: 'app-svg-text',
  templateUrl: './svg-text.component.svg',
  styleUrls: ['./svg-text.component.sass'
]
})
export class SvgTextComponent implements OnInit {

  fillColor = null;

  constructor() {
    this.fillColor = this.getRandomRGB();
  }

  ngOnInit(): void {
  }

  changeColor() {
    this.fillColor = this.getRandomRGB();
  }

  getRandomRGB(){
    const r = Math.floor(Math.random() * 256);
    const g = Math.floor(Math.random() * 256);
    const b = Math.floor(Math.random() * 256);
    return `rgb(${r}, ${g}, ${b})`;
  }
}
