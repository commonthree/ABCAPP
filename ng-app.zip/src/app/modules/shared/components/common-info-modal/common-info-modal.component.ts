import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-common-info-modal',
  templateUrl: './common-info-modal.component.html',
  styleUrls: ['./common-info-modal.component.sass']
})
export class CommonInfoModalComponent implements OnInit {

  title: string;
  message: string;

  constructor(public modalRef: BsModalRef<CommonInfoModalComponent>) { }

  ngOnInit(): void {
  }

}
