import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonInfoModalComponent } from './common-info-modal.component';

describe('CommonInfoModalComponent', () => {
  let component: CommonInfoModalComponent;
  let fixture: ComponentFixture<CommonInfoModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonInfoModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonInfoModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
