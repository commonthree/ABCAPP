import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-status-badge',
  templateUrl: './user-status-badge.component.html',
  styleUrls: ['./user-status-badge.component.sass']
})
export class UserStatusBadgeComponent implements OnInit {


  @Input()
  active: boolean;

  constructor() { }

  ngOnInit(): void {
  }

}
