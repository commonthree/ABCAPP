import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonHttpErrorModalComponent } from './common-http-error-modal.component';

describe('CommonHttpErrorModalComponent', () => {
  let component: CommonHttpErrorModalComponent;
  let fixture: ComponentFixture<CommonHttpErrorModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonHttpErrorModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonHttpErrorModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
