import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-common-http-error-modal',
  templateUrl: './common-http-error-modal.component.html',
  styleUrls: ['./common-http-error-modal.component.sass']
})
export class CommonHttpErrorModalComponent implements OnInit {

  response: HttpErrorResponse;

  constructor(public modalRef: BsModalRef<CommonHttpErrorModalComponent>) { }

  ngOnInit(): void {
  }

}
