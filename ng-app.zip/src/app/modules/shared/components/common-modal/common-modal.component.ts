import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-common-modal',
  templateUrl: './common-modal.component.html',
  styleUrls: ['./common-modal.component.sass']
})
export class CommonModalComponent implements OnInit {


  title: string;
  message: string;

  constructor(public bsModalRef: BsModalRef<CommonModalComponent>) {}

  ngOnInit(): void {
  }

}
