import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputMessageHelperComponent } from './input-message-helper.component';

describe('InputMessageHelperComponent', () => {
  let component: InputMessageHelperComponent;
  let fixture: ComponentFixture<InputMessageHelperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputMessageHelperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputMessageHelperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
