import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-input-message-helper',
  templateUrl: './input-message-helper.component.html',
  styleUrls: ['./input-message-helper.component.sass']
})
export class InputMessageHelperComponent implements OnInit {

  @Input() formGrp: FormGroup
  @Input() formCtrl: FormControl
  @Input() errors: []

  constructor() { }

  ngOnInit(): void {

  }

}
