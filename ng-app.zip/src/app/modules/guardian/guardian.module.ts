import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GuardianRoutingModule } from './guardian-routing.module';
import { GuardianComponent } from './guardian.component';
import { KidListComponent } from './components/kid-list/kid-list.component';
import { KidFormComponent } from './components/kid-form/kid-form.component';
import { KidViewComponent } from './components/kid-view/kid-view.component';


@NgModule({
  declarations: [GuardianComponent, KidListComponent, KidFormComponent, KidViewComponent],
  imports: [
    CommonModule,
    GuardianRoutingModule
  ]
})
export class GuardianModule { }
