import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { KidFormComponent } from './components/kid-form/kid-form.component';
import { KidListComponent } from './components/kid-list/kid-list.component';
import { KidViewComponent } from './components/kid-view/kid-view.component';

import { GuardianComponent } from './guardian.component';

const routes: Routes = [{
  path: '', component: GuardianComponent, children: [
    { path: '', component: KidListComponent },
    { path: 'add', component: KidFormComponent },
    { path: ':id', component: KidViewComponent },
    { path: ':id/edit', component: KidFormComponent }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GuardianRoutingModule { }
