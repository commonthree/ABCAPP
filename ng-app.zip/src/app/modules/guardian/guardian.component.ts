import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guardian',
  templateUrl: './guardian.component.html',
  styleUrls: ['./guardian.component.sass']
})
export class GuardianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
