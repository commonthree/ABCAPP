import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kid-form',
  templateUrl: './kid-form.component.html',
  styleUrls: ['./kid-form.component.sass']
})
export class KidFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
