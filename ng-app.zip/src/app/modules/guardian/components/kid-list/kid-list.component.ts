import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kid-list',
  templateUrl: './kid-list.component.html',
  styleUrls: ['./kid-list.component.sass']
})
export class KidListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
