import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kid-view',
  templateUrl: './kid-view.component.html',
  styleUrls: ['./kid-view.component.sass']
})
export class KidViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
