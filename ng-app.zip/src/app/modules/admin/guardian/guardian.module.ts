import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GuardianRoutingModule } from './guardian-routing.module';
import { GuardianComponent } from './guardian.component';
import { GuardianListComponent } from './guardian-list/guardian-list.component';
import { GuardianFormComponent } from './guardian-form/guardian-form.component';
import { GuardianViewComponent } from './guardian-view/guardian-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { SharedModule } from '../../shared/shared.module';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ButtonsModule } from 'ngx-bootstrap/buttons';


@NgModule({
  declarations: [GuardianComponent, GuardianListComponent, GuardianFormComponent, GuardianViewComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    PaginationModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
    GuardianRoutingModule
  ]
})
export class GuardianModule { }
