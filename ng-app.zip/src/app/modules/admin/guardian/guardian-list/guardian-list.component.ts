import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Guardian } from 'src/app/models/guardian';
import { Page } from 'src/app/models/page';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { GuardianService } from 'src/app/services/guardian.service';

@Component({
  selector: 'app-guardian-list',
  templateUrl: './guardian-list.component.html',
  styleUrls: ['./guardian-list.component.sass']
})
export class GuardianListComponent implements OnInit {

  page: Page<Guardian>;

  constructor(private guardianService: GuardianService, private modalService: CommonModalService) { }

  loadPage(page: PageChangedEvent) {
    this.guardianService.loadPage(page).subscribe(e => this.page = e,
      httpError => this.modalService.showErrorModal(httpError));
  }

  ngOnInit(): void {
    this.loadPage({ page: 1, itemsPerPage: 10 })
  }

}
