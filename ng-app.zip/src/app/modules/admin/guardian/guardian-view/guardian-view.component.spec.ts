import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuardianViewComponent } from './guardian-view.component';

describe('GuardianViewComponent', () => {
  let component: GuardianViewComponent;
  let fixture: ComponentFixture<GuardianViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuardianViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuardianViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
