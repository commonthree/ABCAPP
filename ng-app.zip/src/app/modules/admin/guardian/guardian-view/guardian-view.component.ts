import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Guardian } from 'src/app/models/guardian';
import { Role } from 'src/app/models/role';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { GuardianService } from 'src/app/services/guardian.service';
import { UserRoleService } from 'src/app/services/user-role.service';

@Component({
  selector: 'app-guardian-view',
  templateUrl: './guardian-view.component.html',
  styleUrls: ['./guardian-view.component.sass']
})
export class GuardianViewComponent implements OnInit {

  loading = true;
  userRoleLoading = true;
  user: Guardian;
  roles: Role[];
  userRoles: Role[];

  constructor(private activatedRoute: ActivatedRoute,
    private guardianService: GuardianService,
    private modalService: CommonModalService,
    private userRoleService: UserRoleService) {
      this.userRoleLoading = true;
      activatedRoute.paramMap.subscribe(paramMap => {
        if (paramMap.has('id')) {
          // this.id = parseInt(paramMap.get('id'));
          this.loading = true;
          this.guardianService.get(paramMap.get('id')).subscribe(e => {
            this.user = e;
            this.loading = false;
            this.userRoleService.getRoles().subscribe(e => {
              this.roles = e;
              this.userRoles = this.roles.filter(f => this.user.roles.includes(f.key));
              this.userRoleLoading = false;
            })
        }, this.httpErrorHanlder);
      }
    })

  }

  ngOnInit(): void {
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }

}
