import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardianFormComponent } from './guardian-form/guardian-form.component';
import { GuardianListComponent } from './guardian-list/guardian-list.component';
import { GuardianViewComponent } from './guardian-view/guardian-view.component';

import { GuardianComponent } from './guardian.component';

const routes: Routes = [{ path: '', component: GuardianComponent, children: [
  { path: '', component: GuardianListComponent },
  { path: 'add', component: GuardianFormComponent },
  { path: ':id', component: GuardianViewComponent },
  { path: ':id/edit', component: GuardianFormComponent },
]}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GuardianRoutingModule { }
