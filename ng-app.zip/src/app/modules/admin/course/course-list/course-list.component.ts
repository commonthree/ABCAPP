import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Course } from 'src/app/models/course';
import { Page } from 'src/app/models/page';
import { AuthorizationService } from 'src/app/modules/shared/services/authorization.service';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.sass']
})
export class CourseListComponent implements OnInit {

  page: Page<Course>;
  constructor(private courseService: CourseService, private modalService: CommonModalService,
              public authorizationService: AuthorizationService) {

  }

  loadPage(page: PageChangedEvent = { page: 1, itemsPerPage: 10 }) {
    // console.log(page);
    this.courseService.loadPage(page).subscribe(e => this.page = e,
      httpError => this.modalService.showErrorModal(httpError));
  }

  ngOnInit(): void {
    this.loadPage();
  }

  enroll(id){
    this.courseService.enroll(id).subscribe(d => {
      this.modalService.showModal('Successfully Enrolled', 'you have been enrolled to selected course');
      this.loadPage();
    });
  }

}
