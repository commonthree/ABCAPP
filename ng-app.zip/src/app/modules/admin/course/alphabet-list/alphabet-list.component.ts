import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-alphabet-list',
  templateUrl: './alphabet-list.component.html',
  styleUrls: ['./alphabet-list.component.sass']
})
export class AlphabetListComponent implements OnInit {

  loading = false;
  course: Course;
  BASE_URL = null;

  constructor(private courserService: CourseService, private activatedRoute: ActivatedRoute, private modalService: CommonModalService) {
    this.BASE_URL = environment.BASE_URL;
  }

  ngOnInit(): void {
    this.loading = true;
    this.activatedRoute.paramMap.subscribe(paramMap => {
      if (paramMap.has("id")) {
        this.courserService.getByKeyAndId('alphabet', paramMap.get("id")).subscribe(c => {
          this.course = c;
          this.loading = false;
        }, this.httpErrorHanlder);
      }
    })
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }

}
