import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlphabetExerciseIComponent } from './alphabet-exercise-i.component';

describe('AlphabetExerciseIComponent', () => {
  let component: AlphabetExerciseIComponent;
  let fixture: ComponentFixture<AlphabetExerciseIComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlphabetExerciseIComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlphabetExerciseIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
