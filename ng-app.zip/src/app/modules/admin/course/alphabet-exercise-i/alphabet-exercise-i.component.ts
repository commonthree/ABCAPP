import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-alphabet-exercise-i',
  templateUrl: './alphabet-exercise-i.component.html',
  styleUrls: ['./alphabet-exercise-i.component.sass']
})
export class AlphabetExerciseIComponent implements OnInit {

  loading = false;
  course: Course;
  randomChars: {
    character: string;
    status: string;
  }[];
  selectedChar: string;
  selectedChars: string[];

  constructor(private activatedRoute: ActivatedRoute, private courserService: CourseService) {
    this.selectedChars = Array();
  }

  courseId = null;

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(pm => {
      if (pm.has('id')){
        this.courseId = pm.get('id');
        this.play();
      }
    });
  }

  shuffle(){
    this.selectedChars = this.course.alphabetaList.filter(e => e.status === 'RIGHT').map(e => e.character);
    this.randomChars = this.course.alphabetaList
                        .map(e => {
                          return {
                            character: e.character,
                            status: e.status == null || e.status === 'WRONG' ? 'NOT_SELECTED' : e.status
                          };
                        })
                        .sort(() => 0.5 - Math.random());
  }

  play(replay = false){
    this.loading = true;
    this.courserService.getAlphabetExerciseIProgress(this.courseId, replay).subscribe(e => {
      this.course = e;
      this.shuffle();
      this.loading = false;
    });
  }

  select(c: {character: string, status: string}){
    if (c.status === 'WRONG'){
      c.status = 'NOT_SELECTED';
      this.selectedChars.pop();
    } else if (c.status === 'NOT_SELECTED') {
      let lastIndex = this.selectedChars.length - 1;
      const wrongRandomChar = this.randomChars.find(e => e.status === 'WRONG');
      if (wrongRandomChar == null){
        lastIndex = this.selectedChars.push(c.character) - 1;
      } else {
        wrongRandomChar.status = 'NOT_SELECTED';
        const e = this.selectedChars.find(e => wrongRandomChar.character === e);
        if (e){
          this.selectedChars.slice(this.selectedChars.indexOf(e), 1);
        }
        this.selectedChars.pop();
        lastIndex = this.selectedChars.push(c.character) - 1;
      }
      if (this.selectedChars[lastIndex].toUpperCase()
        === this.course.alphabetaList[lastIndex].character.toUpperCase()){
          c.status = 'RIGHT';
        } else {
          c.status = 'WRONG';
      }
    }
    this.courserService.updateAlphabetExerciseIProgress(this.course.id, c).subscribe(e => {
      console.log(e);
    });
  }

}
