import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlphabetExerciseIProgressComponent } from './alphabet-exercise-i-progress.component';

describe('AlphabetExerciseIProgressComponent', () => {
  let component: AlphabetExerciseIProgressComponent;
  let fixture: ComponentFixture<AlphabetExerciseIProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlphabetExerciseIProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlphabetExerciseIProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
