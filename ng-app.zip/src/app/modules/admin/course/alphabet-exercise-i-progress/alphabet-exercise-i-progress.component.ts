import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-alphabet-exercise-i-progress',
  templateUrl: './alphabet-exercise-i-progress.component.html',
  styleUrls: ['./alphabet-exercise-i-progress.component.sass']
})
export class AlphabetExerciseIProgressComponent implements OnInit {

  courseId: string;
  userId: string;
  courses: Course[];
  loading = false;
  constructor(private activatedRoute: ActivatedRoute, private courseService: CourseService) {
    this.activatedRoute.paramMap.subscribe(e => {
      if (e.has('id')){
        this.courseId = e.get('id');
      }
      if(e.has('userId')){
        this.userId = e.get('userId');
      }
    });
  }

  ngOnInit(): void {
    this.loading = true;
    this.courseService.getAlphabetExerciseIProgresses(this.courseId, this.userId).subscribe(e => {
      this.courses = e;
    });
  }

}
