import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlphabetExerciseIiComponent } from './alphabet-exercise-ii.component';

describe('AlphabetExerciseIiComponent', () => {
  let component: AlphabetExerciseIiComponent;
  let fixture: ComponentFixture<AlphabetExerciseIiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlphabetExerciseIiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlphabetExerciseIiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
