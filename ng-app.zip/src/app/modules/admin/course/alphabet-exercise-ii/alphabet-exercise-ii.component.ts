import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alphabet-exercise-ii',
  templateUrl: './alphabet-exercise-ii.component.html',
  styleUrls: ['./alphabet-exercise-ii.component.sass']
})
export class AlphabetExerciseIiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
