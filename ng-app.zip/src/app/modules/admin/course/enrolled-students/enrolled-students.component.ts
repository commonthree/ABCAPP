import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Page } from 'src/app/models/page';
import { Student } from 'src/app/models/student';
import { AuthorizationService } from 'src/app/modules/shared/services/authorization.service';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { StudentService } from 'src/app/services/student.service';

@Component({
  selector: 'app-enrolled-students',
  templateUrl: './enrolled-students.component.html',
  styleUrls: ['./enrolled-students.component.sass']
})
export class EnrolledStudentsComponent implements OnInit {

  page: Page<Student>;
  courseId: string;

  constructor(private studentService: StudentService, private modalService: CommonModalService,
              public authorizationService: AuthorizationService,
              private activatedRoute: ActivatedRoute) {
    this.activatedRoute.paramMap.subscribe(paramMap => {
      if (paramMap.has('id')){
        this.courseId = paramMap.get('id');
      }
    });
  }

  loadPage(pce: PageChangedEvent) {
    this.studentService.loadStudentPageByCourseId(pce, this.courseId).subscribe(
      e => this.page = e,
      he => this.modalService.showErrorModal(he));
  }

  ngOnInit(): void {
    this.loadPage({ page: 1, itemsPerPage: 10 });
  }

}
