import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlphabetExerciseIProgressComponent } from './alphabet-exercise-i-progress/alphabet-exercise-i-progress.component';
import { AlphabetExerciseIComponent } from './alphabet-exercise-i/alphabet-exercise-i.component';
import { AlphabetExerciseIiComponent } from './alphabet-exercise-ii/alphabet-exercise-ii.component';
import { AlphabetListComponent } from './alphabet-list/alphabet-list.component';
import { CharacterViewComponent } from './character-view/character-view.component';
import { CourseFormComponent } from './course-form/course-form.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseViewComponent } from './course-view/course-view.component';

import { CourseComponent } from './course.component';
import { EnrolledStudentsComponent } from './enrolled-students/enrolled-students.component';
import { MyCoursesComponent } from './my-courses/my-courses.component';
import { NumberListComponent } from './number-list/number-list.component';
import { NumberViewComponent } from './number-view/number-view.component';

const routes: Routes = [{
  path: '', component: CourseComponent, children: [
    { path: '', component: CourseListComponent },
    { path: 'my', component: MyCoursesComponent },
    { path: 'alphabet/:id', component: AlphabetListComponent },
    { path: 'alphabet/:id/exercise-i', component: AlphabetExerciseIComponent },
    { path: 'alphabet/:id/exercise-i/progress', component: AlphabetExerciseIProgressComponent },
    { path: 'alphabet/:id/exercise-i/progress/:userId', component: AlphabetExerciseIProgressComponent },
    { path: 'alphabet/:id/exercise-ii', component: AlphabetExerciseIiComponent },
    { path: 'alphabet/:id/:char', component: CharacterViewComponent },
    { path: 'number/:id', component: NumberListComponent },
    { path: 'number/:id/:num', component: NumberViewComponent },
    { path: ':id/edit', component: CourseFormComponent },
    { path: ':id/enrolled', component: EnrolledStudentsComponent },
    { path: ':type/:id', component: CourseViewComponent },
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CourseRoutingModule { }
