import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NumberView } from 'src/app/models/number-view';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-number-view',
  templateUrl: './number-view.component.html',
  styleUrls: ['./number-view.component.sass']
})
export class NumberViewComponent implements OnInit {

  numberView: NumberView;
  loading = true;

  constructor(private activatedRoute: ActivatedRoute, private courseService: CourseService,
              private modalService: CommonModalService) {
    this.activatedRoute.paramMap.subscribe(paramMap => {
      if (paramMap.has('num')){
        this.courseService.getByKeyAndIdAndNumber('number', paramMap.get('id'), paramMap.get('num'))
          .subscribe(e => {
            this.numberView = e;
            this.loading = false;
          }, e => {
            this.modalService.showErrorModal(e);
            this.loading = false;
          });
      }
    });
  }

  ngOnInit(): void {
  }

}
