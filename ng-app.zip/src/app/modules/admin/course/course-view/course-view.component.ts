import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-course-view',
  templateUrl: './course-view.component.html',
  styleUrls: ['./course-view.component.sass']
})
export class CourseViewComponent implements OnInit {

  loading = false;
  course: Course;

  constructor(private courserService: CourseService, private activatedRoute: ActivatedRoute, private modalService: CommonModalService) { }

  ngOnInit(): void {
    this.loading = true;
    this.activatedRoute.paramMap.subscribe(paramMap => {
      if(paramMap.has('id')){
        this.courserService.getById(paramMap.get('id')).subscribe(c => {
          this.course = c;
          this.loading = false;
        }, this.httpErrorHanlder);
      }
    })
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }

}
