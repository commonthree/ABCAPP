import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CourseRoutingModule } from './course-routing.module';
import { CourseComponent } from './course.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CourseFormComponent } from './course-form/course-form.component';
import { CourseViewComponent } from './course-view/course-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { AlphabetListComponent } from './alphabet-list/alphabet-list.component';
import { NumberListComponent } from './number-list/number-list.component';
import { MyCoursesComponent } from './my-courses/my-courses.component';
import { CharacterViewComponent } from './character-view/character-view.component';
import { NumberViewComponent } from './number-view/number-view.component';
import { EnrolledStudentsComponent } from './enrolled-students/enrolled-students.component';
import { AlphabetExerciseIComponent } from './alphabet-exercise-i/alphabet-exercise-i.component';
import { AlphabetExerciseIiComponent } from './alphabet-exercise-ii/alphabet-exercise-ii.component';
import { AlphabetExerciseIProgressComponent } from './alphabet-exercise-i-progress/alphabet-exercise-i-progress.component';


@NgModule({
  declarations: [CourseComponent,
    CourseListComponent,
    CourseFormComponent,
    CourseViewComponent,
    AlphabetListComponent,
    NumberListComponent,
    MyCoursesComponent,
    CharacterViewComponent,
    NumberViewComponent,
    EnrolledStudentsComponent,
    AlphabetExerciseIComponent,
    AlphabetExerciseIiComponent,
    AlphabetExerciseIProgressComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    PaginationModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
    CourseRoutingModule
  ]
})
export class CourseModule { }
