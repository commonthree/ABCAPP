import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Course } from 'src/app/models/course';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-number-list',
  templateUrl: './number-list.component.html',
  styleUrls: ['./number-list.component.sass']
})
export class NumberListComponent implements OnInit {

  loading = false;
  course: Course;
  BASE_URL: string;

  constructor(private courserService: CourseService, private activatedRoute: ActivatedRoute, private modalService: CommonModalService) {
    this.BASE_URL = environment.BASE_URL;
  }

  ngOnInit(): void {
    this.loading = true;
    this.activatedRoute.paramMap.subscribe(paramMap => {
      if (paramMap.has("id")) {
        this.courserService.getByKeyAndId('number', paramMap.get("id")).subscribe(c => {
          this.course = c;
          this.loading = false;
        }, this.httpErrorHanlder);
      }
    })
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }
}
