import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CharacterView } from 'src/app/models/character-view';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-character-view',
  templateUrl: './character-view.component.html',
  styleUrls: ['./character-view.component.sass']
})
export class CharacterViewComponent implements OnInit {

  characterView: CharacterView;
  loading = true;

  constructor(private activatedRoute: ActivatedRoute, private courseService: CourseService,
              private modalService: CommonModalService) {
    this.activatedRoute.paramMap.subscribe(paramMap => {
      if (paramMap.has('char')){
        this.courseService.getByKeyAndIdAndChar('alphabet', paramMap.get('id'), paramMap.get('char'))
          .subscribe(e => {
            this.characterView = e;
            this.loading = false;
          }, e => {
            this.modalService.showErrorModal(e);
            this.loading = false;
          });
      }
    });
  }

  ngOnInit(): void {
  }

}
