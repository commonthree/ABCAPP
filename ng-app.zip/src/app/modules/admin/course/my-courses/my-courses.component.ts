import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Course } from 'src/app/models/course';
import { Page } from 'src/app/models/page';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { CourseService } from 'src/app/services/course.service';

@Component({
  selector: 'app-my-courses',
  templateUrl: './my-courses.component.html',
  styleUrls: ['./my-courses.component.sass']
})
export class MyCoursesComponent implements OnInit {

  page: Page<Course>;
  constructor(private courseService: CourseService, private modalService: CommonModalService) {

  }

  loadPage(page: PageChangedEvent) {
    // console.log(page);
    this.courseService.loadPageMyCourse(page).subscribe(e => this.page = e,
      httpError => this.modalService.showErrorModal(httpError));
  }

  ngOnInit(): void {
    let pageEvent = { page: 1, itemsPerPage: 10 }
    this.loadPage(pageEvent);
  }

}
