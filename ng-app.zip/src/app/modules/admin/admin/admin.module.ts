import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AdminListComponent } from './admin-list/admin-list.component';
import { AdminFormComponent } from './admin-form/admin-form.component';
import { AdminViewComponent } from './admin-view/admin-view.component';
import { PaginationModule } from 'ngx-bootstrap/pagination'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { AngularDualListBoxModule } from 'angular-dual-listbox';


@NgModule({
  declarations: [AdminComponent, AdminListComponent, AdminFormComponent, AdminViewComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    PaginationModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
    AngularDualListBoxModule,
    AdminRoutingModule
  ]
})
export class AdminModule { }
