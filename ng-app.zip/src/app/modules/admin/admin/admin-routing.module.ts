import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserRoleComponent } from 'src/app/components/user-role/user-role.component';
import { AdminFormComponent } from './admin-form/admin-form.component';
import { AdminListComponent } from './admin-list/admin-list.component';
import { AdminViewComponent } from './admin-view/admin-view.component';

import { AdminComponent } from './admin.component';

const routes: Routes = [{
  path: '', component: AdminComponent, children: [
    { path: '', component: AdminListComponent },
    { path: 'add', component: AdminFormComponent },
    { path: ':id', component: AdminViewComponent },
    { path: ':id/edit', component: AdminFormComponent },
    { path: 'userrole/:id', component: UserRoleComponent }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
