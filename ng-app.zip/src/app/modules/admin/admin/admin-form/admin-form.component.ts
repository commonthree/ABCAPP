import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, RequiredValidator, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Alert } from 'src/app/models/alert';
import { User } from 'src/app/models/user';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AdminService } from 'src/app/services/admin.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-admin-form',
  templateUrl: './admin-form.component.html',
  styleUrls: ['./admin-form.component.sass']
})
export class AdminFormComponent implements OnInit {

  alerts: Alert[] = []
  saving = false;
  loading = false;
  formGroup = new FormGroup({
    'firstName': new FormControl(null),
    'lastName': new FormControl(null),
    'email': new FormControl(null, [Validators.required]),
    'username': new FormControl(null),
    'active': new FormControl(false, Validators.required)
  })

  user: User;

  inputErrors = {
    firstName: [],
    lastName: [],
    username: [],
    email: [],
    active: []
  }

  constructor(private activatedRoute: ActivatedRoute, private adminService: AdminService, private userService: UserService,
    private modalService: CommonModalService) {
      activatedRoute.paramMap.subscribe(paramMap => {
        if (paramMap.has('id')) {
          // this.id = parseInt(paramMap.get('id'));
          this.loading = true;
          this.adminService.get(paramMap.get('id')).subscribe(e => {
            this.user = e;
            this.reset();
            this.loading = false;
          }, this.httpErrorHanlder);
        }
    })
  }

  ngOnInit(): void {

  }

  onSubmit() {
    if (this.formGroup.valid) {
      this.saving = true;
      this.alerts = [];
      let u = this.formGroup.value;
      if(this.user){
        u.id = this.user.id;
      }
      this.adminService.save(u).subscribe(e => {
        this.alerts.push(new Alert('Success', 'User has been updated', 'success'));
        this.saving = false;
      }, this.httpErrorHanlder);
    }
  }



  reset(){
    if(this.user){
      this.formGroup.controls.email.setValue(this.user.email);
      this.formGroup.controls.username.setValue(this.user.username);
      this.formGroup.controls.firstName.setValue(this.user.firstName);
      this.formGroup.controls.lastName.setValue(this.user.lastName);
      this.formGroup.controls.active.setValue(this.user.active);
    } else {
      this.formGroup.reset();
    }
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.saving = false;
    this.loading = false;
  }

}
