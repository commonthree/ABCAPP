import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Admin } from 'src/app/models/admin';
import { Role } from 'src/app/models/role';
import { User } from 'src/app/models/user';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AdminService } from 'src/app/services/admin.service';
import { UserRoleService } from 'src/app/services/user-role.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-admin-view',
  templateUrl: './admin-view.component.html',
  styleUrls: ['./admin-view.component.sass']
})
export class AdminViewComponent implements OnInit {

  loading = true;
  userRoleLoading = true;
  user: Admin;
  roles: Role[];
  userRoles: Role[];

  constructor(private activatedRoute: ActivatedRoute,
    private adminService: AdminService,
    private modalService: CommonModalService,
    private userRoleService: UserRoleService) {
      this.userRoleLoading = true;
      activatedRoute.paramMap.subscribe(paramMap => {
        if (paramMap.has('id')) {
          // this.id = parseInt(paramMap.get('id'));
          this.loading = true;
          this.adminService.get(paramMap.get('id')).subscribe(e => {
            this.user = e;
            this.loading = false;
            this.userRoleService.getRoles().subscribe(e => {
              this.roles = e;
              this.userRoles = this.roles.filter(f => this.user.roles.includes(f.key));
              this.userRoleLoading = false;
            })
        }, this.httpErrorHanlder);
      }
    })

  }

  ngOnInit(): void {
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }

}
