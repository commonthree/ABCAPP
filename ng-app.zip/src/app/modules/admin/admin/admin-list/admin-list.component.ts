import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Admin } from 'src/app/models/admin';
import { Page } from 'src/app/models/page';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AdminService } from 'src/app/services/admin.service';

@Component({
  selector: 'app-admin-list',
  templateUrl: './admin-list.component.html',
  styleUrls: ['./admin-list.component.sass']
})
export class AdminListComponent implements OnInit {

  page: Page<Admin>;

  constructor(private adminService: AdminService, private modalService: CommonModalService) { }

  loadPage(page: PageChangedEvent) {
    // console.log(page);
    this.adminService.loadPage(page).subscribe(e => this.page = e,
      httpError => this.modalService.showErrorModal(httpError));
  }

  ngOnInit(): void {
    let pageEvent = { page: 1, itemsPerPage: 10 }
    this.loadPage(pageEvent);
  }

}
