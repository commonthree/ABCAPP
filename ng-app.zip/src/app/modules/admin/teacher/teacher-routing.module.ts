import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TeacherFormComponent } from './teacher-form/teacher-form.component';
import { TeacherListComponent } from './teacher-list/teacher-list.component';
import { TeacherViewComponent } from './teacher-view/teacher-view.component';

import { TeacherComponent } from './teacher.component';

const routes: Routes = [{
  path: '', component: TeacherComponent, children: [
    { path: '', component: TeacherListComponent },
    { path: 'add', component: TeacherFormComponent },
    { path: ':id', component: TeacherViewComponent },
    { path: ':id/edit', component: TeacherFormComponent }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TeacherRoutingModule { }
