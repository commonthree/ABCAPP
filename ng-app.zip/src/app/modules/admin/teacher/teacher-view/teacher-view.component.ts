import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Role } from 'src/app/models/role';
import { Teacher } from 'src/app/models/teacher';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { TeacherService } from 'src/app/services/teacher.service';
import { UserRoleService } from 'src/app/services/user-role.service';

@Component({
  selector: 'app-teacher-view',
  templateUrl: './teacher-view.component.html',
  styleUrls: ['./teacher-view.component.sass']
})
export class TeacherViewComponent implements OnInit {

  loading = true;
  userRoleLoading = true;
  user: Teacher;
  roles: Role[];
  userRoles: Role[];

  constructor(private activatedRoute: ActivatedRoute,
    private teacherService: TeacherService,
    private modalService: CommonModalService,
    private userRoleService: UserRoleService) {
      this.userRoleLoading = true;
      activatedRoute.paramMap.subscribe(paramMap => {
        if (paramMap.has('id')) {
          // this.id = parseInt(paramMap.get('id'));
          this.loading = true;
          this.teacherService.get(paramMap.get('id')).subscribe(e => {
            this.user = e;
            this.loading = false;
            this.userRoleService.getRoles().subscribe(e => {
              this.roles = e;
              this.userRoles = this.roles.filter(f => this.user.roles.includes(f.key));
              this.userRoleLoading = false;
            })
        }, this.httpErrorHanlder);
      }
    })

  }

  ngOnInit(): void {
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }
}
