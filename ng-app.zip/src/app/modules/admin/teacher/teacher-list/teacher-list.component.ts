import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Page } from 'src/app/models/page';
import { Teacher } from 'src/app/models/teacher';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { TeacherService } from 'src/app/services/teacher.service';

@Component({
  selector: 'app-teacher-list',
  templateUrl: './teacher-list.component.html',
  styleUrls: ['./teacher-list.component.sass']
})
export class TeacherListComponent implements OnInit {

  page: Page<Teacher>;

  constructor(private teacherService: TeacherService, private modalService: CommonModalService) { }

  loadPage(pce: PageChangedEvent) {
    this.teacherService.loadPage(pce).subscribe(e => this.page = e,
      httpError => this.modalService.showErrorModal(httpError));
  }

  ngOnInit(): void {
    this.loadPage({ page: 1, itemsPerPage: 10 });
  }

}
