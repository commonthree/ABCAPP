import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Role } from 'src/app/models/role';
import { Student } from 'src/app/models/student';
import { AuthorizationService } from 'src/app/modules/shared/services/authorization.service';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { StudentService } from 'src/app/services/student.service';
import { UserRoleService } from 'src/app/services/user-role.service';

@Component({
  selector: 'app-student-view',
  templateUrl: './student-view.component.html',
  styleUrls: ['./student-view.component.sass']
})
export class StudentViewComponent implements OnInit {

  loading = true;
  userRoleLoading = true;
  user: Student;
  roles: Role[];
  userRoles: Role[];

  constructor(private activatedRoute: ActivatedRoute,
    private studentService: StudentService,
    private modalService: CommonModalService,
    private userRoleService: UserRoleService,
    public authorizationService: AuthorizationService) {
      this.userRoleLoading = true;
      activatedRoute.paramMap.subscribe(paramMap => {
        if (paramMap.has('id')) {
          // this.id = parseInt(paramMap.get('id'));
          this.loading = true;
          this.studentService.get(paramMap.get('id')).subscribe(e => {
            this.user = e;
            
            this.loading = false;
            this.userRoleService.getRoles().subscribe(e => {
              this.roles = e;
              this.userRoles = this.roles.filter(f => this.user.roles.includes(f.key));
              this.userRoleLoading = false;
            })
        }, this.httpErrorHanlder);
      }
    })

  }

  ngOnInit(): void {
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }

}
