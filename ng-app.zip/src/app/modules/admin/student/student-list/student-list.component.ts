import { Component, OnInit } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Page } from 'src/app/models/page';
import { Student } from 'src/app/models/student';
import { AuthorizationService } from 'src/app/modules/shared/services/authorization.service';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { StudentService } from 'src/app/services/student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.sass']
})
export class StudentListComponent implements OnInit {

  page: Page<Student>;

  constructor(private studentService: StudentService, private modalService: CommonModalService,
    public authorizationService: AuthorizationService) { }

  loadPage(pce: PageChangedEvent) {
    this.studentService.loadPage(pce).subscribe(e => this.page = e, he => this.modalService.showErrorModal(he));
  }

  ngOnInit(): void {
    this.loadPage({ page: 1, itemsPerPage: 10 })
  }

}
