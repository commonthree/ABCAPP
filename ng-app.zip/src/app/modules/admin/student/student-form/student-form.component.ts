import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Alert } from 'src/app/models/alert';
import { PersonRelation } from 'src/app/models/person-relation';
import { Student } from 'src/app/models/student';
import { User } from 'src/app/models/user';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { PersonRelationService } from 'src/app/services/person-relation.service';
import { StudentService } from 'src/app/services/student.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.sass']
})
export class StudentFormComponent implements OnInit {

  alerts: Alert[] = []
  personRelations: PersonRelation[];
  saving = false;
  loading = false;
  loadingPersonRelations = false;
  formGroup = new FormGroup({
    'firstName': new FormControl(null),
    'lastName': new FormControl(null),
    'email': new FormControl(null, [Validators.required]),
    'username': new FormControl(null),
    'active': new FormControl(true, Validators.required),
    'relationId': new FormControl(null, Validators.required)
  })

  user: Student;

  inputErrors = {
    firstName: [],
    lastName: [],
    username: [],
    email: [],
    active: [],
    relationId: []
  }

  constructor(private activatedRoute: ActivatedRoute, private studentService: StudentService, private userService: UserService,
    private modalService: CommonModalService,
    private personRelationService: PersonRelationService) {
      activatedRoute.paramMap.subscribe(paramMap => {
        if (paramMap.has('id')) {
          // this.id = parseInt(paramMap.get('id'));
          this.loading = true;
          this.studentService.getForm(paramMap.get('id')).subscribe(e => {
            this.user = e;
            this.reset();
            this.loading = false;
          }, this.httpErrorHanlder);
        }
      })
    }

    ngOnInit(): void {
      this.loadingPersonRelations = true;
      this.personRelationService.getAll().subscribe(e => {
        this.personRelations = e;
        if(!this.formGroup.controls.relationId.value){
          console.log(this.formGroup.controls.relationId.value);
          this.formGroup.controls.relationId.setValue(this.personRelations[0].id);
        }
        this.loadingPersonRelations = false;
      }, (httpError) => {
        this.loadingPersonRelations = false;
        this.httpErrorHanlder(httpError);
      });
  }

  onSubmit() {
    if (this.formGroup.valid) {
      this.saving = true;
      this.alerts = [];
      let u = this.formGroup.value;
      if(this.user){
        u.id = this.user.id;
      }
      this.studentService.save(u).subscribe(e => {
        this.alerts.push(new Alert('Success', 'User has been updated', 'success'));
        this.saving = false;
      }, this.httpErrorHanlder);
    }
  }



  reset(){
    if(this.user){
      this.formGroup.controls.email.setValue(this.user.email);
      this.formGroup.controls.username.setValue(this.user.username);
      this.formGroup.controls.firstName.setValue(this.user.firstName);
      this.formGroup.controls.lastName.setValue(this.user.lastName);
      this.formGroup.controls.active.setValue(this.user.active);
      if(this.user.guardianShips && this.user.guardianShips[0] && this.user.guardianShips[0].relation){
        this.formGroup.controls.relationId.setValue(this.user.guardianShips[0].relation.id);
      }
    } else {
      this.formGroup.reset();
    }
  }

  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.saving = false;
    this.loading = false;
  }
}
