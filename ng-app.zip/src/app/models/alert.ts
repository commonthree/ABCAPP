export class Alert {
  title: string;
  message: string;
  type: string;
  dismissible: boolean;
  dismissOnTimeout: number;
  show: boolean;

  constructor(title, message, type, dismissible=false, dismissOnTimeout=5000, show=true){
    this.title = title;
    this.message = message;
    this.type = type;
    this.dismissible = dismissible;
    this.dismissOnTimeout = dismissOnTimeout;
    this.show = show;
  }
}
