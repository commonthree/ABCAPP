import { Model } from "./model";

export class ListModel {
  page: number;
  totalPages: number;
  totalItems: number;
  list: Model[];
}
