import { Nav } from './nav';

describe('Nav', () => {
  it('should create an instance', () => {
    expect(new Nav()).toBeTruthy();
  });
});
