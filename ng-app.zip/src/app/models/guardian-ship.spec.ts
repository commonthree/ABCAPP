import { GuardianShip } from './guardian-ship';

describe('GuardianShip', () => {
  it('should create an instance', () => {
    expect(new GuardianShip()).toBeTruthy();
  });
});
