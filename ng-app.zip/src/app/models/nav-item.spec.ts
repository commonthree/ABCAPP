import { NavItem } from './nav-item';

describe('NavItem', () => {
  it('should create an instance', () => {
    expect(new NavItem()).toBeTruthy();
  });
});
