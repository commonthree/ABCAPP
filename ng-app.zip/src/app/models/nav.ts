import { NavItem } from "./nav-item"

export class Nav {
  title: string
  url: string
  navItems: NavItem[]
}
