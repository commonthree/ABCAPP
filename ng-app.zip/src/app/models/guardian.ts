import { GuardianShip } from "./guardian-ship";
import { User } from "./user";

export class Guardian extends User {
  guardianShips: GuardianShip[]
}
