import { Guardian } from './guardian';

describe('Guardian', () => {
  it('should create an instance', () => {
    expect(new Guardian()).toBeTruthy();
  });
});
