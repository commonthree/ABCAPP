import { Model } from "./model";

export class HttpErrorResponse {
  timestamp: string;
  status: string;
  message: string;
  error: string;
  errors: [{
    field: string,
    defaultMessage: string
  }];
}
