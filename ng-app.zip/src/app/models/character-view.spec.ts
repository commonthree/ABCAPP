import { CharacterView } from './character-view';

describe('CharacterView', () => {
  it('should create an instance', () => {
    expect(new CharacterView()).toBeTruthy();
  });
});
