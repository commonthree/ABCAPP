import { HttpErrorResponse } from "./http-response";

export class AuthResponse extends HttpErrorResponse {
  token: string;
}
