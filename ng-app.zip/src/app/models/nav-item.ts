import { Nav } from "./nav"

export class NavItem {
  title: string
  url: string
  nav: Nav
}
