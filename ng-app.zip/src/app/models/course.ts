export class Course {
  id: number
  title: string
  type: string
  enrolled: boolean
  numberList: number[]
  alphabetaList: {
    character: string;
    status: string;
    wrongCount: number;
    imageCover: string;
    narrationAudioFile: string;
  }[]
}
