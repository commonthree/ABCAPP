import { Guardian } from "./guardian";
import { PersonRelation } from "./person-relation";

export class GuardianShip {
  guardian: Guardian;
  relation: PersonRelation;
}
