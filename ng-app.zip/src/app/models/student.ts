import { Course } from "./course";
import { Guardian } from "./guardian";
import { GuardianShip } from "./guardian-ship";
import { User } from "./user";

export class Student extends User {
  guardianShips: GuardianShip[]
  courses: Course[]
}
