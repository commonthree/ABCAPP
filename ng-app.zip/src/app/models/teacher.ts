import { User } from "./user";

export class Teacher extends User {
}
