export class NumberView {
  coverImage: string;
  current: number;
  next: number;
  previous: number;
}
