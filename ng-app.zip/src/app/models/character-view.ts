export class CharacterView {
  coverImage: string;
  current: string;
  next: string;
  previous: string;
}
