import { NumberView } from './number-view';

describe('NumberView', () => {
  it('should create an instance', () => {
    expect(new NumberView()).toBeTruthy();
  });
});
