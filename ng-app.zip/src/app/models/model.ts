export class Model {
  id: string;
}
