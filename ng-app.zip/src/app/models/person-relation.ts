export class PersonRelation {
  id: number;
  name: string;
}
