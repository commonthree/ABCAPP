import { PersonRelation } from './person-relation';

describe('PersonRelation', () => {
  it('should create an instance', () => {
    expect(new PersonRelation()).toBeTruthy();
  });
});
