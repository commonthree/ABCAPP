export class Role {
  key: string;
  value: string;
}
