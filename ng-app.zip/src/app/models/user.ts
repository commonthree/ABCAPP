import { Model } from "./model";
import { Role } from "./role";

export class User extends Model {
  username: string;
  email: string;
  password: string;
  token: string;
  roles: string[];
  firstName: string;
  lastName: string;
  active: boolean;
  fullName: string;
}
