export class Page<T> {
  number: number
  size: number
  totalItems: number
  items: T[]
}
