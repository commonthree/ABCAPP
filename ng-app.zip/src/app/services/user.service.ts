import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private SERVICE_URL = "/secure/api/users";

  constructor(private httpClient: HttpClient) { }

  public getUser(): Observable<User> {
    return this.httpClient.get<User>(`${environment.BASE_URL}${this.SERVICE_URL}/currentuser`);
  }

  public get(id: string): Observable<User> {
    return this.httpClient.get<User>(`${environment.BASE_URL}${this.SERVICE_URL}/${id}`);
  }

  public save(user: User): Observable<User> {
    return this.httpClient.post<User>(`${environment.BASE_URL}${this.SERVICE_URL}`, user);
  }
}
