import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Role } from '../models/role';

@Injectable({
  providedIn: 'root'
})
export class UserRoleService {

  private SERVICE_URL = "/public/api/user/roles";

  private _roles: Role[]

  constructor(private httpClient: HttpClient) { }

  public getRolesForRegistration(): Observable<Role[]> {
    return this.httpClient.get<Role[]>(`${environment.BASE_URL}${this.SERVICE_URL}/registeration`);
  }

  public getRoles(): Observable<Role[]> {
    return this.httpClient.get<Role[]>(`${environment.BASE_URL}${this.SERVICE_URL}`);
  }

  public addUserRole(id: string, roles: string[]) {
    return this.httpClient.post(`${environment.BASE_URL}${this.SERVICE_URL}/${id}`, roles);
  }

  public removeUserRole(id: string, roles: string[]) {
    return this.httpClient.delete(`${environment.BASE_URL}${this.SERVICE_URL}/${id}`, {
      params: { 'roles': roles }
    });
  }


}
