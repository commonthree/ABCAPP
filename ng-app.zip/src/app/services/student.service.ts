import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Page } from '../models/page';
import { Student } from '../models/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private SERVICE_URL = "/secure/api/students";

  constructor(private httpClient: HttpClient) { }

  public loadPage(pce: PageChangedEvent) {
    return this.httpClient.get<Page<Student>>(`${environment.BASE_URL}${this.SERVICE_URL}`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    });
  }

  public loadStudentPageByCourseId(pce: PageChangedEvent, courseId: string) {
    return this.httpClient.get<Page<Student>>(`${environment.BASE_URL}${this.SERVICE_URL}/course/${courseId}`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    })
  }

  public get(id: string){
    return this.httpClient.get<Student>(`${environment.BASE_URL.concat(this.SERVICE_URL)}/${id}`)
  }

  public getForm(id: string){
    return this.httpClient.get<Student>(`${environment.BASE_URL.concat(this.SERVICE_URL)}/${id}/edit`)
  }

  public save(user: Student): Observable<Student> {
    return this.httpClient.post<Student>(`${environment.BASE_URL}${this.SERVICE_URL}`, user);
  }

}
