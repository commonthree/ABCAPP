import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Guardian } from '../models/guardian';
import { Page } from '../models/page';

@Injectable({
  providedIn: 'root'
})
export class GuardianService {

  private SERVICE_URL = "/secure/api/guardians";

  constructor(private httpClient: HttpClient) { }

  public loadPage(pce: PageChangedEvent) {
    return this.httpClient.get<Page<Guardian>>(`${environment.BASE_URL}${this.SERVICE_URL}`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    })
  }

  public get(id: string){
    return this.httpClient.get<Guardian>(`${environment.BASE_URL.concat(this.SERVICE_URL)}/${id}`)
  }

  public save(user: Guardian): Observable<Guardian> {
    return this.httpClient.post<Guardian>(`${environment.BASE_URL}${this.SERVICE_URL}`, user);
  }
}
