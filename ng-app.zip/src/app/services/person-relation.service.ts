import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { PersonRelation } from '../models/person-relation';

@Injectable({
  providedIn: 'root'
})
export class PersonRelationService {

  private SERVICE_URL = "/secure/api/personrelation";

  constructor(private httpClient: HttpClient) { }

  public getAll(){
    return this.httpClient.get<PersonRelation[]>(`${environment.BASE_URL}${this.SERVICE_URL}`);
  }
}
