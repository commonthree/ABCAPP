import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CharacterView } from '../models/character-view';
import { Course } from '../models/course';
import { NumberView } from '../models/number-view';
import { Page } from '../models/page';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  private SERVICE_URL = "/secure/api/courses";

  constructor(private httpClient: HttpClient) { }

  public loadPage(pce: PageChangedEvent): Observable<Page<Course>> {
    return this.httpClient.get<Page<Course>>(`${environment.BASE_URL}${this.SERVICE_URL}`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    });
  }

  public loadPageMyCourse(pce: PageChangedEvent): Observable<Page<Course>> {
    return this.httpClient.get<Page<Course>>(`${environment.BASE_URL}${this.SERVICE_URL}/my`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    });
  }

  public getById(id: string){
    return this.httpClient.get<Course>(`${environment.BASE_URL}${this.SERVICE_URL}/${id}`);
  }

  public getByKeyAndId(key: string, id: string){
    return this.httpClient.get<Course>(`${environment.BASE_URL}${this.SERVICE_URL}/${key}/${id}`);
  }

  public getByKeyAndIdAndChar(key: string, id: string, char: string){
    return this.httpClient.get<CharacterView>(`${environment.BASE_URL}${this.SERVICE_URL}/${key}/${id}/${char}`);
  }

  public getByKeyAndIdAndNumber(key: string, id: string, n: string){
    return this.httpClient.get<NumberView>(`${environment.BASE_URL}${this.SERVICE_URL}/${key}/${id}/${n}`);
  }

  public enroll(id: string){
    return this.httpClient.post<Course>(`${environment.BASE_URL}${this.SERVICE_URL}/enroll/`, id);
  }

  public updateAlphabetExerciseIProgress(id, progress){
    return this.httpClient.post<Course>(`${environment.BASE_URL}${this.SERVICE_URL}/alphabet/${id}/exercise-i`, progress);
  }

  public getAlphabetExerciseIProgress(id, replay){
    return this.httpClient.get<Course>(`${environment.BASE_URL}${this.SERVICE_URL}/alphabet/${id}/exercise-i`, {
      params: {
        replay: `${replay}`
      }
    });
  }

  public getAlphabetExerciseIProgresses(id, userId){
    if (userId === undefined || userId == null ){
      return this.httpClient.get<Course[]>(`${environment.BASE_URL}${this.SERVICE_URL}/alphabet/${id}/exercise-i/progress`);
    }
    return this.httpClient.get<Course[]>(`${environment.BASE_URL}${this.SERVICE_URL}/alphabet/${id}/exercise-i/progress/${userId}`);
  }

}
