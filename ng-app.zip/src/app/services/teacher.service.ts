import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Page } from '../models/page';
import { Teacher } from '../models/teacher';

@Injectable({
  providedIn: 'root'
})
export class TeacherService {

  private SERVICE_URL = "/secure/api/teachers";

  constructor(private httpClient: HttpClient) { }

  public loadPage(pce: PageChangedEvent) {
    return this.httpClient.get<Page<Teacher>>(`${environment.BASE_URL}${this.SERVICE_URL}`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    })
  }

  public get(id: string){
    return this.httpClient.get<Teacher>(`${environment.BASE_URL.concat(this.SERVICE_URL)}/${id}`)
  }

  public save(user: Teacher): Observable<Teacher> {
    return this.httpClient.post<Teacher>(`${environment.BASE_URL}${this.SERVICE_URL}`, user);
  }
}
