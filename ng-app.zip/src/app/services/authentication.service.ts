import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { AuthResponse } from '../models/auth-response';
import { HttpErrorResponse } from '../models/http-response';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  logout() {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
  }

  constructor(private httpClient: HttpClient) { } ng

  private SERVICE_URL = "/auth";
  private _authenticatedUser: User;
  private _token: string;

  set authenticatedUser(user: User) {
    this._authenticatedUser = user;
    localStorage.setItem("user", JSON.stringify(user));
  }

  get authenticatedUser() {
    if (!this._authenticatedUser) {
      this._authenticatedUser = JSON.parse(localStorage.getItem("user"));
    }
    return this._authenticatedUser;
  }

  set token(token: string) {
    this._token = token;
    localStorage.setItem("token", token);
  }

  get token() {
    if (!this._token) {
      this._token = localStorage.getItem("token");
    }
    return this._token;
  }

  public isTokenValid() {
    return this.httpClient.get<boolean>(`${environment.BASE_URL}${this.SERVICE_URL}/istokenvalid`, {
      params: { token: this._token }
    });
  }

  public login(email: string, password: string) {
    return this.httpClient.post<AuthResponse>(`${environment.BASE_URL}${this.SERVICE_URL}/authenticate`, {
      email: email,
      password: password
    })
  }

  public register(user: User, role: string) {
    return this.httpClient.post<HttpErrorResponse>(`${environment.BASE_URL}${this.SERVICE_URL}/register`, {
      email: user.email,
      password: user.password,
      role: role
    })
  }

  public forgotPassword(email: string) {
    return this.httpClient.post<HttpErrorResponse>(`${environment.BASE_URL}${this.SERVICE_URL}/password/forgot`, {
      email: email,
    })
  }

  public resetPassword(token: string, passwrod: string) {
    return this.httpClient.post<HttpErrorResponse>(`${environment.BASE_URL}${this.SERVICE_URL}/password/reset/${token}`, {
      password: passwrod
    })
  }

}
