import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Nav } from '../models/nav';

@Injectable({
  providedIn: 'root'
})
export class AppUtilService {

  constructor(private httpClient: HttpClient) { }

  public getMenu(roleKey: string){
    return this.httpClient.get<Nav>(`/assets/data/${roleKey}_menu.json`);
  }
}
