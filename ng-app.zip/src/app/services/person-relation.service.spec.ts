import { TestBed } from '@angular/core/testing';

import { PersonRelationService } from './person-relation.service';

describe('PersonRelationService', () => {
  let service: PersonRelationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PersonRelationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
