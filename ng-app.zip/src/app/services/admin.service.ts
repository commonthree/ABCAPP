import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Admin } from '../models/admin';
import { Page } from '../models/page';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private SERVICE_URL = "/secure/api/admins";

  constructor(private httpClient: HttpClient) { }

  public loadPage(pce: PageChangedEvent) {
    return this.httpClient.get<Page<Admin>>(`${environment.BASE_URL}${this.SERVICE_URL}`, {
      params: {
        'pageNumber': `${pce.page}`,
        'pageSize': `${pce.itemsPerPage}`
      }
    })
  }

  public get(id: string){
    return this.httpClient.get<Admin>(`${environment.BASE_URL.concat(this.SERVICE_URL)}/${id}`)
  }

  public save(user: Admin): Observable<Admin> {
    return this.httpClient.post<Admin>(`${environment.BASE_URL}${this.SERVICE_URL}`, user);
  }

}
