import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Nav } from 'src/app/models/nav';
import { Role } from 'src/app/models/role';
import { User } from 'src/app/models/user';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AppUtilService } from 'src/app/services/app-util.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserRoleService } from 'src/app/services/user-role.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-top-header-layout',
  templateUrl: './top-header-layout.component.html',
  styleUrls: ['./top-header-layout.component.sass']
})
export class TopHeaderLayoutComponent implements OnInit {

  authUser: User;
  roles: Role[] = [{ key: null, value: 'None' }]
  nav: Nav;
  loading = false;

  constructor(private authService: AuthenticationService,
    private userService: UserService,
    private userRoleService: UserRoleService,
    private utilService: AppUtilService,
    private modalService: CommonModalService,
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private router: Router) { }

  ngOnInit(): void {
    this.authUser = this.authService.authenticatedUser;

    this.authenticationService.isTokenValid().subscribe({
      next: e => {
        if (!e) {
          this.authenticationService.logout();
        }
      },
      complete: () => this.loading = false,
      error: this.httpErrorHandler
    });


    this.userRoleService.getRoles().subscribe(r => {
      this.roles = r;
      if (!this.authUser) {
        this.userService.getUser().subscribe(e => {
          this.authUser = e;
          if (this.authUser.roles) {
            this.userSetting();
          }
        }, this.httpErrorHandler);
      } else {
        this.userSetting();
      }
    }, this.httpErrorHandler);
  }

  httpErrorHandler = (httpError) => {
    this.modalService.showErrorModal(httpError).onHidden.subscribe(e => {
      this.logout();
    })
  }

  userSetting() {
    this.roles = this.roles.filter(f => this.authUser.roles.includes(f.key));
    this.selectedRole = this.roles[0];
    this.changeMenu(this.selectedRole.key);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['login'])
  }

  selectedRole: Role;

  onChangeRole() {
    // console.log(this.selectedRole);
    this.changeMenu(this.selectedRole.key);
  }

  changeMenu(roleKey: string) {
    this.utilService.getMenu(roleKey).subscribe(e => {
      this.nav = e;
      let url = this.router.url.split('/')[1];
      if (this.nav.navItems.filter(f => f.url == `/${url}`).length == 0) {
        this.router.navigate([this.nav.navItems[0].url])
      }
      // console.log(this.activatedRoute.snapshot.url)
    });
  }

}
