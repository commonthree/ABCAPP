import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Alert } from 'src/app/models/alert';
import { Role } from 'src/app/models/role';
import { User } from 'src/app/models/user';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserRoleService } from 'src/app/services/user-role.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.sass']
})
export class RegisterComponent implements OnInit {

  alerts: Alert[] = [];
  roles: Role[] = [];

  processing = false;

  inputErrors = {
    email: [],
    password: [],
    role: []
  }

  form = new FormGroup({
    'email': new FormControl('', [Validators.required, Validators.email]),
    'password': new FormControl('', [Validators.required]),
    'role': new FormControl(null, [Validators.required])
  })

  constructor(private authenticationService: AuthenticationService,
    private userRoleService: UserRoleService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private modalService: CommonModalService) { }

  rolesUploading = false;
  ngOnInit(): void {
    this.loadingRoles();
  }

  loadingRoles(){
    if(this.roles.length == 0){
      this.rolesUploading = true;
      this.userRoleService.getRolesForRegistration().subscribe(e => {
        this.roles = e;
        this.rolesUploading = false;
      }, httpError => {
        this.modalService.showErrorModal(httpError);
        this.rolesUploading = false;
      })
    }
  }

  submit() {
    this.alerts = [];
    this.inputErrors = {
      email: [],
      password: [],
      role: []
    };
    if (this.form.valid) {
      this.processing = true;
      // console.log(this.form.value);
      let user = new User();
      user.email = this.form.value.email;
      user.password = this.form.value.password;
      this.authenticationService.register(user, this.form.value.role)
      .subscribe(response => {
        this.processing = false;
        console.log(response);
        this.modalService.showInfoModal("Success", "Email registered successfully").onHide.subscribe( () => {
          this.router.navigate(['/login']);
        })
      },
      // end success block
      (error) => {
        this.processing = false;
        console.log(error);
        if (error && error.error) {
            if (error.error.errors) {
              error.error.errors.forEach(e => {
                console.log(e);
                if(this.inputErrors[e.field]){
                  this.inputErrors[e.field].push(e.defaultMessage);
                }
              });
            } else if (error.error.error && (typeof error.error.error === 'string')) {
              this.alerts.push(new Alert(error.error.error, error.error.message, 'danger', true, 0));
            } else {
              this.modalService.showErrorModal(error);
            }
          }
        })
        // end catch error block
    }
  }

}
