import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Alert } from 'src/app/models/alert';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.sass']
})
export class LoginComponent implements OnInit {

  alerts: Alert[] = [];

  processing = false;

  inputErrors = {
    email: [],
    password: []
  }

  form = new FormGroup({
    'email': new FormControl('', [Validators.required, Validators.email]),
    'password': new FormControl('', [Validators.required])
  })

  constructor(
    private authenticationService: AuthenticationService,
    private userService: UserService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private modalService: CommonModalService) { }

  ngOnInit(): void {
  }

  submit() {
    this.alerts = [];
    this.inputErrors = {
      email: [],
      password: []
    };
    if (this.form.valid) {
      this.processing = true;
      this.authenticationService.login(this.form.value.email, this.form.value.password)
        .subscribe(response => {
          this.processing = false;
          // console.log(response);
          this.authenticationService.token = response.token;
          this.userService.getUser().subscribe(e => {
            this.authenticationService.authenticatedUser = e
            if (this.activatedRoute.snapshot.queryParams && this.activatedRoute.snapshot.queryParams.url) {
              this.router.navigateByUrl(this.activatedRoute.snapshot.queryParams.url);
            }
            else {
              this.router.navigate(['/']);
            }
          });
        },
          // end success block
          (httpError) => {
            this.processing = false;
            console.log(httpError);
            if (httpError && httpError.error) {
              if (httpError.error.errors) {
                httpError.error.errors.forEach(e => {
                  console.log(e);
                  if (this.inputErrors[e.field]) {
                    this.inputErrors[e.field].push(e.defaultMessage);
                  }
                });
              } else if (httpError.error.error && (typeof httpError.error.error === 'string')) {
                this.alerts.push(new Alert(httpError.error.error, httpError.error.message, 'danger', true, 0));
              } else {
                this.modalService.showErrorModal(httpError);
              }
            }
          })
      // end catch error block
    }
  }

}
