import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Alert } from 'src/app/models/alert';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.sass']
})
export class ResetPasswordComponent implements OnInit {

  alerts: Alert[] = [];

  processing = false;

  inputErrors = {
    password: []
  }

  form = new FormGroup({
    'password': new FormControl('', [Validators.required]),
    'confirmPassword': new FormControl('', [Validators.required])
  })

  constructor(private authenticationService: AuthenticationService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private modalService: CommonModalService) { }

  ngOnInit(): void {
  }

  submit() {
    this.alerts = [];
    this.inputErrors = {
      password: []
    };
    if (this.form.valid) {
      this.processing = true;
      let token = this.activatedRoute.snapshot.params.token;
      this.authenticationService.resetPassword(token, this.form.value.password)
      .subscribe(response => {
        this.processing = false;
        console.log(response);
        this.modalService.showInfoModal("Password Reset", "Now login with your new password").onHide.subscribe(()=>{
          this.router.navigate(['/login']);
        })
      },
      // end success block
      (error) => {
        this.processing = false;
        console.log(error);
        if (error && error.error) {
            if (error.error.errors) {
              error.error.errors.forEach(e => {
                console.log(e);
                if(this.inputErrors[e.field]){
                  this.inputErrors[e.field].push(e.defaultMessage);
                }
              });
            } else if (error.error.error && (typeof error.error.error === 'string')) {
              this.alerts.push(new Alert(error.error.error, error.error.message, 'danger', true, 0));
            } else {
              this.modalService.showErrorModal(error);
            }
          }
        })
        // end catch error block
    }
  }

}
