import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Role } from 'src/app/models/role';
import { User } from 'src/app/models/user';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { UserRoleService } from 'src/app/services/user-role.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-user-role',
  templateUrl: './user-role.component.html',
  styleUrls: ['./user-role.component.sass']
})
export class UserRoleComponent implements OnInit {

  loading = true;
  userRoleLoading = true;
  user: User;
  roles: Role[];
  userRoles: Role[];
  userId: string;

  constructor(private activatedRoute: ActivatedRoute,
    private userService: UserService,
    private modalService: CommonModalService,
    private bsModalService: BsModalService,
    private userRoleService: UserRoleService) {
    this.userRoleLoading = true;
    activatedRoute.paramMap.subscribe(paramMap => {
      if (paramMap.has('id')) {
        this.userId = paramMap.get('id');
        this.loadUserData();
      }
    })
  }

  loadUserData() {
    this.loading = true;
    this.userService.get(this.userId).subscribe(e => {
      this.user = e;
      this.loading = false;
      if (!this.roles) {
        this.userRoleService.getRoles().subscribe(e => {
          this.roles = e;
          this.loadUserRoles();
          this.userRoleLoading = false;
        }, this.httpErrorHanlder)
      } else {
        this.loadUserRoles();
      }
    });
  }

  loadUserRoles() {
    this.userRoles = this.roles.filter(f => this.user.roles.includes(f.key));
  }

  ngOnInit(): void {
  }

  onDestinationChange(ar: Role[]) {
    console.log(ar);
    if (ar.length > this.user.roles.length) {
      // add
      let roles = ar.filter(f => !this.user.roles.includes(f.key));
      // console.log(`add: ${roles.map(f => f.key)}`);
      this.userRoleService.addUserRole(this.user.id, roles.map(f => f.key)).subscribe(e => {
        this.loadUserData();
      }, this.httpErrorHanlder)
    } else if (ar.length < this.user.roles.length) {
      // remove
      console.log(`user.roles.length: ${this.user.roles.length}, remove array length: ${ar.length}`)
      if (ar.length > 0) {
        let urs = [];
        Object.assign(urs, this.user.roles);
        let roles = urs.filter(ur => !ar.find(f => f.key == ur));
        // console.log(`remove: ${roles}`);
        this.userRoleService.removeUserRole(this.user.id, roles).subscribe(e => {
          this.loadUserData();
        }, this.httpErrorHanlder)
      } else {
        this.modalService.showModal("Error", "At least 1 role is required. can't remove all")
          .onHide.subscribe(() => this.loadUserData());
      }
    }
  }


  httpErrorHanlder = (httpError: HttpErrorResponse) => {
    this.modalService.showErrorModal(httpError);
    this.loading = false;
  }

}
