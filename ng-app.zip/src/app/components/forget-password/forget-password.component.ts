import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Alert } from 'src/app/models/alert';
import { HttpErrorResponse } from 'src/app/models/http-response';
import { CommonModalService } from 'src/app/modules/shared/services/common-modal.service';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.sass']
})
export class ForgetPasswordComponent implements OnInit {

  alerts: Alert[] = [];

  processing = false;

  inputErrors = {
    email: []
  }

  form = new FormGroup({
    'email': new FormControl('', [Validators.required, Validators.email])
  })

  constructor(private authenticationService: AuthenticationService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private modalService: CommonModalService) { }

  ngOnInit(): void {
  }

  submit() {
    this.alerts = [];
    this.inputErrors = {
      email: []
    };
    if (this.form.valid) {
      this.processing = true;
      this.authenticationService.forgotPassword(this.form.value.email)
      .subscribe(response => {
        this.processing = false;
        console.log(response);
        this.alerts.push(new Alert("Success", "check your email inbox", "success", true, 0));
      },
      // end success block
      (error) => {
        this.processing = false;
        console.log(error);
        if (error && error.error) {
            if (error.error.errors) {
              error.error.errors.forEach(e => {
                console.log(e);
                if(this.inputErrors[e.field]){
                  this.inputErrors[e.field].push(e.defaultMessage);
                }
              });
            } else if (error.error.error && (typeof error.error.error === 'string')) {
              this.alerts.push(new Alert(error.error.error, error.error.message, 'danger', true, 0));
            } else {
              this.modalService.showErrorModal(error);
            }
          }
        })
        // end catch error block
    }
  }

}
