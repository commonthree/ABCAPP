package com.app.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.AlphabetaExerciseI;
import com.app.model.AlphabetaExerciseIProgress;
import com.app.model.CharacterView;
import com.app.model.NumberView;
import com.app.model.Page;
import com.app.repository.CourseRepository;
import com.app.repository.entity.Alphabeta;
import com.app.repository.entity.Course;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;

@Service
@Transactional(readOnly = true)
public class CourseService {
	
	@Autowired
	private CourseRepository courseRepository;

	public Page<Course> getCourses(int pageNumber, int pageSize, User user) {
		Page<Course> page = new Page<Course>(pageNumber, pageSize);
		if(user != null && user.getRoles() != null && user.getRoles().contains(Role.STUDENT)) {
			return this.courseRepository.getCourses(page, user.getId());			
		}
		return this.courseRepository.getCourses(page);			
	}
	
	private Course getCourseById(Long id, Long userId) {
		return this.courseRepository.getCourse(id, userId);
	}

	public Course getAlphabetByCourseId(Long id, Long userId) {
		Course course = getCourseById(id, userId);
		course.setAlphabetaList(this.courseRepository.getAlphabetaListByCourseId(course.getId()));
		return course;
	}

	public Course getNumberByCourseId(Long id, Long userId) {
		Course course = this.getCourseById(id, userId);
		List<Number> numberList = new ArrayList<>();
		for (int i = 1; i <= 10; i++) {
			numberList.add(i);
		}
		course.setNumberList(numberList);
		return course;
	}

	public Page<Course> getByEnrolledUserId(int pageNumber, int pageSize, Long id) {
		Page<Course> page = new Page<Course>(pageNumber, pageSize);
		return this.courseRepository.getByEnrolledUserId(page, id);
	}

	@Transactional(readOnly = false)
	public Course enroll(Long userId, Long courseId) {
		this.courseRepository.enroll(userId, courseId);
		return this.getCourse(courseId, userId);
	}

	public Course getCourse(Long courseId, Long userId) {
		return this.courseRepository.getCourse(courseId, userId);
	}

	public CharacterView getCharacterView(Character c) {
		return new CharacterView(c);
	}

	public NumberView getNumberView(Long id, Number number) {
		return new NumberView(number);
	}

	public List<Course> getCourseByStudentId(Long id) {
		return this.courseRepository.getCourseByStudentId(id);
	}

	@Transactional(readOnly = false)
	public Course getAlphabetCourseExerciseI(Long courseId, Long userId, boolean replay) {
		Course course = getCourseById(courseId, userId);
		course.setAlphabetaList(this.courseRepository.getAlphabetExerciseI(course.getId(), this.getAlphabetaExerciseISessionId(courseId, userId, replay)));
		return course;
	}

	@Transactional(readOnly = false)
	public Course setAlphabetCourseExerciseI(Long courseId, Long userId, AlphabetaExerciseIProgress alphabetaStudentProgress) {
		Long sessionId = getAlphabetaExerciseISessionId(courseId, userId);
		this.courseRepository.setAlphabetExerciseIProgress(sessionId, alphabetaStudentProgress.getCharacterAscii(), alphabetaStudentProgress.getStatus());
		return this.getCourseById(courseId, userId);
	}

	private Long getAlphabetaExerciseISessionId(Long courseId, Long userId) {
		return getAlphabetaExerciseISessionId(courseId, userId, false);
	}

	private Long getAlphabetaExerciseISessionId(Long courseId, Long userId, boolean replay) {
		if(replay) {
			return this.courseRepository.createAlphabetExerciseSession(courseId, userId);
		}
		AlphabetaExerciseI exerciseI = this.courseRepository.getAlphabetExerciseSession(courseId, userId);
		if(exerciseI == null) {
			return this.courseRepository.createAlphabetExerciseSession(courseId, userId);
		} else {
			return exerciseI.getSessionId();
		}
	}

	public List<Course> getAlphabetCourseExerciseIProgress(Long courseId, Long userId) {
		List<Course> courses = this.courseRepository.getAlphabetCourseExerciseISessions(courseId, userId);
		courses.parallelStream().forEach(c -> c.setAlphabetaList(this.courseRepository.getAlphabetCourseExerciseIProgress(c.getSessionId())));
		return courses;
	}

}
