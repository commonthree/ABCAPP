package com.app.service;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Admin;
import com.app.model.Guardian;
import com.app.model.Page;
import com.app.model.Teacher;
import com.app.repository.UserRepository;
import com.app.repository.UserRoleRepository;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;

@Service
@Transactional(readOnly = false)
public class TeacherService {

	@Autowired
	public UserRepository userRepository;
	@Autowired
	private UserRoleRepository userRoleRepository;

	public Page<Teacher> getTeachers(Map<String, String> filters, String sortBy, String sortOrder, int pageNumber,
			int pageSize) {
		Page<Teacher> page = new Page<Teacher>(pageNumber, pageSize);
		this.userRepository.getUsersByRoles(Role.TEACHER, page);
		return page;
	}

	public Teacher get(Long id) {
		User user = this.userRepository.getUserById(id);
		user.setRoles(this.userRoleRepository.getRolesByUserId(user.getId()).stream().collect(Collectors.toList()));
		return new Teacher(user);
	}

}
