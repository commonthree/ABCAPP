package com.app.service;

import java.util.stream.Collectors;

import javax.mail.MessagingException;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Student;
import com.app.repository.StudentGuardianRepository;
import com.app.repository.UserRepository;
import com.app.repository.UserRoleRepository;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.throwable.EmailNotFoundException;
import com.app.throwable.InvalidTokenException;
import com.app.throwable.UserEmailAlreadyExistsException;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Autowired
	private AppMailService appMailService;

	public User getUserByUsernameOrEmail(String username) {
		User user = this.userRepository.getUserDetailsByUsernameOrEmail(username);
		user.setRoles(userRoleRepository.getRolesByUserId(user.getId()).stream().collect(Collectors.toList()));
		return user;
	}

	public User getUserByUsernameOrEmail() {
		return this.getUserByUsernameOrEmail(SecurityContextHolder.getContext().getAuthentication().getName());
	}

	@Transactional(readOnly = false)
	public void register(User user) throws UserEmailAlreadyExistsException {
		if (this.userRepository.getUserByEmail(user.getEmail()) != null) {
			throw new UserEmailAlreadyExistsException(String.format("email %s already registered", user.getEmail()));
		}
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		Long userId = this.userRepository.register(user);
		if (user.getRoles() != null) {
			for (Role role : user.getRoles()) {
				userRoleRepository.insertUserRole(userId, role);
			}
		}
	}

	@Transactional(readOnly = false)
	public void updateLastLogin(Long id) {
		this.userRepository.updateLastLogin(id);
	}

	@Transactional
	public void forgotPassword(String email) throws EmailNotFoundException, MessagingException {
		User user = this.userRepository.getUserByEmail(email);
		if (user == null)
			throw new EmailNotFoundException(String.format("email '%s' not found", email));
		String token = RandomStringUtils.randomAlphanumeric(6);
		this.appMailService.sendEmail(email, "Spring Boot App - Password Reset", String.format(
				"Hi Spring boot app user, click this link \"http://localhost:8080/#/password/reset/%s\" to reset password",
				token));
		this.userRepository.updateResetPasswordToken(user.getId(), token);
	}

	@Transactional(rollbackFor = MessagingException.class)
	public void resetPassword(String token, String password) throws InvalidTokenException, MessagingException {
		User user = this.userRepository.getUserByToken(token);
		if (user == null || !user.getResetPasswordToken().equals(token))
			throw new InvalidTokenException(String.format("Invalid or expired token."));
		this.userRepository.updatePassword(user.getId(), bCryptPasswordEncoder.encode(password));
		this.appMailService.sendEmail(user.getEmail(), "Spring Boot App - Password Reset",
				"Hi Spring boot app user, your password has been reset. now login with your new password");
	}

	@Transactional(readOnly = false)
	public User update(User user) throws MessagingException {
		if (user.getId() != null && user.getId() > 0)
			return this.userRepository.update(user);
		String password = "abcd1234"; // RandomStringUtils.randomAlphanumeric(8);
		user.setPassword(this.bCryptPasswordEncoder.encode(password));
		Long id = this.userRepository.save(user);
		if (!user.getRoles().isEmpty()) {
			this.userRoleRepository.insertUserRole(id, user.getRoles().get(0));
		}
		user = this.userRepository.getUserById(id);
		this.appMailService.sendEmail(user.getEmail(), "Account Created on ABC", String.format(
				"Dear %s, \n Your account has been created, your email id '%s' and password is '%s' without quoted. ",
				user.getFirstName(), user.getEmail(), password));
		return user;
	}

	public User get(Long id) {
		User user = this.userRepository.getUserById(id);
		user.setRoles(this.userRoleRepository.getRolesByUserId(id).stream().collect(Collectors.toList()));
		return user;
	}

	@Autowired
	private StudentGuardianRepository studentGuardianRepository;

	@Transactional(readOnly = false)
	public Student updateStudent(Student student) throws MessagingException {
		User persistedStudent = this.update(student);
		this.studentGuardianRepository.add(student.getGuardianShips().get(0).getGuardian().getId(), persistedStudent.getId(),
				student.getGuardianShips().get(0).getRelation().getId());
		return student;
	}
}
