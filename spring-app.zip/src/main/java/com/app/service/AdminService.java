package com.app.service;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Admin;
import com.app.model.Page;
import com.app.repository.UserRepository;
import com.app.repository.UserRoleRepository;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;

@Service
@Transactional(readOnly = false)
public class AdminService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserRoleRepository userRoleRepository;

	public Page<Admin> getAdmins(Map<String, String> filters, String sortBy, String sortOrder, int pageNumber,
			int pageSize) {
		Page<Admin> page = new Page<Admin>(pageNumber, pageSize);
		this.userRepository.getUsersByRoles(Role.ADMIN, page);
		return page;
	}

	public Admin get(Long id) {
		User user = this.userRepository.getUserById(id);
		user.setRoles(this.userRoleRepository.getRolesByUserId(user.getId()).stream().collect(Collectors.toList()));
		return new Admin(user);
	}

}
