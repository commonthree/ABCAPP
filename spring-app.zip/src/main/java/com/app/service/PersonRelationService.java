package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.PersonRelation;
import com.app.repository.PersonRelationRepository;

@Service
@Transactional(readOnly = true)
public class PersonRelationService {

	@Autowired
	private PersonRelationRepository personRelationRepository;

	public List<PersonRelation> getAll() {
		return this.personRelationRepository.getAll();
	}
}
