package com.app.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.repository.UserRoleRepository;
import com.app.repository.entity.Role;

@Service
@Transactional(readOnly = true)
public class UserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepository;

	public List<HashMap<Object, Object>> getRoles() {
		return map(this.userRoleRepository.getRoles());
	}

	public List<HashMap<Object, Object>> getRolesForRegistration() {
		return map(this.userRoleRepository.getRolesForRegistration());
	}
	
	public List<HashMap<Object, Object>> map(Collection<? extends Role> collection) {
		List<HashMap<Object, Object>> roleMaps = new ArrayList<>();
		if(collection != null) {
			roleMaps = collection.stream().map(f -> {
				HashMap<Object,Object> map = new HashMap<>();
				map.put("key", f.name());
				map.put("value", f.getName());
				return map;
			}).collect(Collectors.toList());
		}
		return roleMaps;
	}

	@Transactional(readOnly = false)
	public int addUserRoles(Long userId, String[] roles) {
		return this.userRoleRepository.insertUserRoles(userId, roles);
	}
	
	@Transactional(readOnly = false)
	public int removeUserRoles(Long userId, String[] roles) {
		return this.userRoleRepository.deleteUserRoles(userId, roles);
	}
}
