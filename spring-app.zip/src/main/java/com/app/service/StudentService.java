package com.app.service;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Guardian;
import com.app.model.GuardianShip;
import com.app.model.Page;
import com.app.model.PersonRelation;
import com.app.model.Student;
import com.app.repository.CourseRepository;
import com.app.repository.PersonRelationRepository;
import com.app.repository.StudentGuardianRepository;
import com.app.repository.UserRepository;
import com.app.repository.UserRoleRepository;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.web.rest.controller.GuardianRestController;

@Service
@Transactional(readOnly = true)
public class StudentService {

	@Autowired
	public UserRepository userRepository;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Autowired
	private StudentGuardianRepository studentGuardianRepository;
	
	@Autowired
	private CourseRepository courseRepository;

	public Page<Student> getStudents(Map<String, String> filters, String sortBy, String sortOrder, int pageNumber,
			int pageSize) {
		Page<Student> page = new Page<Student>(pageNumber, pageSize);
		this.userRepository.getUsersByRoles(Role.STUDENT, page);
		return page;
	}

	public Page<Student> getGuardianStudents(Long userId, int pageNumber, int pageSize) {
		Page<Student> page = new Page<Student>(pageNumber, pageSize);
		this.userRepository.getStudentsByGuardianId(userId, page);
		return page;
	}

	public Student get(Long id) {
		return this.getByStudentAndGuardianId(id, null);
	}

	public Student getByStudentAndGuardianId(Long studentId, Long guardianId) {
		User user = this.userRepository.getUserById(studentId);
		user.setRoles(this.userRoleRepository.getRolesByUserId(user.getId()).stream().collect(Collectors.toList()));
		Student student = new Student(user);

		if (guardianId != null)
			student.setGuardianShips(
					this.studentGuardianRepository.getGuardianShipsByStudentAndGuardianId(studentId, guardianId));
		else
			student.setGuardianShips(this.studentGuardianRepository.getGuardianShipsByStudentId(studentId));
		
		student.setCourses(this.courseRepository.getCourseByStudentId(student.getId()));

		return student;
	}

	public Page<Student> getStudentsByCourse(int pageNumber, int pageSize, Long courseId) {
		Page<Student> page = new Page<Student>(pageNumber, pageSize);
		this.userRepository.getStudentsByCourse(courseId, page);
		return page;
	}
}
