package com.app.service;

import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Guardian;
import com.app.model.Page;
import com.app.repository.StudentGuardianRepository;
import com.app.repository.UserRepository;
import com.app.repository.UserRoleRepository;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;

@Service
@Transactional(readOnly = false)
public class GuardianService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private StudentGuardianRepository studentGuardianRepository;
	
	@Autowired
	private UserRoleRepository userRoleRepository;

	public Page<Guardian> getGuardians(Map<String, String> filters, String sortBy, String sortOrder, int pageNumber,
			int pageSize) {
		Page<Guardian> page = new Page<Guardian>(pageNumber, pageSize);
		this.userRepository.getUsersByRoles(Role.GUARDIAN, page);
		return page;
	}

	public Guardian get(Long id) {
		User user = this.userRepository.getUserById(id);
		user.setRoles(this.userRoleRepository.getRolesByUserId(user.getId()).stream().collect(Collectors.toList()));
		Guardian guardian = new Guardian(user);
		guardian.setGuardianShips(this.studentGuardianRepository.getGuardianShipsByGuardianId(guardian.getId()));
		return guardian;
	}

	public Page<Guardian> getGuardiansByStudentId(Long id, int pageNumber, int pageSize) {
		Page<Guardian> page = new Page<Guardian>(pageNumber, pageSize);
		this.userRepository.getGuardiansByStudentId(id, page);
		return page;
	}
}