package com.app.throwable;

public class UserEmailAlreadyExistsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4604991740584298059L;

	public UserEmailAlreadyExistsException(String message) {
		super(message);
	}

	public UserEmailAlreadyExistsException() {
		super();
	}

	public UserEmailAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public UserEmailAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
	}

	public UserEmailAlreadyExistsException(Throwable cause) {
		super(cause);
	}

}
