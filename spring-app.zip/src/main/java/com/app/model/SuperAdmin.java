package com.app.model;

import com.app.repository.entity.User;

public class SuperAdmin extends User {

}
