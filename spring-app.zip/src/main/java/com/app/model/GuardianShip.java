package com.app.model;

public class GuardianShip {
	private Student student;
	private Guardian guardian;
	private PersonRelation relation;

	public GuardianShip() {
		super();
	}

	public GuardianShip(Guardian guardian, PersonRelation relation) {
		super();
		this.guardian = guardian;
		this.relation = relation;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Guardian getGuardian() {
		return guardian;
	}

	public void setGuardian(Guardian guardian) {
		this.guardian = guardian;
	}

	public PersonRelation getRelation() {
		return relation;
	}

	public void setRelation(PersonRelation relation) {
		this.relation = relation;
	}

}
