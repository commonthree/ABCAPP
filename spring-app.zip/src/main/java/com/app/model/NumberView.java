package com.app.model;

public class NumberView {
	private String coverImage;
	private Number current;
	private Number next;
	private Number previous;
	
	public NumberView() {
		this.setCoverImage("/img/600x200/");
	}

	public NumberView(Number number) {
		this();
		this.current = number;
		this.setCoverImage(this.getCoverImage().concat(this.current.toString()).concat(".png"));
		this.previous = getPrevious(number);
		this.next = getNext(number);
	}

	private Number getNext(Number number) {
		if(number.intValue() < 10)
			return number.intValue() + 1;
		return null;
	}

	private Number getPrevious(Number number) {
		if (number.intValue() < 0)
			return null;
		return number.intValue() - 1;
	}

	public Number getCurrent() {
		return current;
	}

	public void setCurrent(Number current) {
		this.current = current;
	}

	public Number getNext() {
		return next;
	}

	public void setNext(Number next) {
		this.next = next;
	}

	public Number getPrevious() {
		return previous;
	}

	public void setPrevious(Number previous) {
		this.previous = previous;
	}

	public String getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(String coverImage) {
		this.coverImage = coverImage;
	}

}
