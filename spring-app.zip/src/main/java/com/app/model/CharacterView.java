package com.app.model;

public class CharacterView {
	private String coverImage;
	private Character current;
	private Character next;
	private Character previous;

	public CharacterView() {
		this.coverImage = "/img/600x200/";
	}

	public CharacterView(char c) {
		this();
		this.current = c;
		this.coverImage = this.coverImage.concat(String.valueOf(c).concat(".png"));
		this.next = this.getNext(c);
		this.previous = this.getPrevious(c);
	}

	private Character getNext(char c) {
		if(Character.toLowerCase(c) >= 'a' && Character.toLowerCase(c) < 'z') {
			return (char) (c + 1);
		}
		return null;			
	}

	private Character getPrevious(char c) {
		if(Character.toLowerCase(c) > 'a' && Character.toLowerCase(c) <= 'z') {
			return (char) (c - 1);
		}
		return null;
	}

	public Character getCurrent() {
		return current;
	}

	public void setCurrent(Character character) {
		this.current = character;
	}

	public Character getNext() {
		return next;
	}

	public void setNext(Character next) {
		this.next = next;
	}

	public Character getPrevious() {
		return previous;
	}

	public void setPrevious(Character previous) {
		this.previous = previous;
	}

	public String getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(String coverImage) {
		this.coverImage = coverImage;
	}

}
