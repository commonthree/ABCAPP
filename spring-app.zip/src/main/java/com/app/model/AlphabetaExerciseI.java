package com.app.model;

import java.util.List;

public class AlphabetaExerciseI {

	private Long sessionId;
	private Integer courseId;
	private Long studentId;
	private String exercise;

	private List<AlphabetaExerciseIProgress> progress;
	
	public AlphabetaExerciseI() {}

	public AlphabetaExerciseI(long sessionId, int courseId, long studentId, String exercise) {
		this.sessionId = sessionId;
		this.courseId = courseId;
		this.studentId = studentId;
		this.setExercise(exercise);
	}

	public Long getSessionId() {
		return sessionId;
	}

	public void setSessionId(Long session) {
		this.sessionId = session;
	}

	public List<AlphabetaExerciseIProgress> getProgress() {
		return progress;
	}

	public void setProgress(List<AlphabetaExerciseIProgress> progress) {
		this.progress = progress;
	}

	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getExercise() {
		return exercise;
	}

	public void setExercise(String exercise) {
		this.exercise = exercise;
	}

}
