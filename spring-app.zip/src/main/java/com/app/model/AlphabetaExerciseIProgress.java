package com.app.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class AlphabetaExerciseIProgress {

	public static final String NOT_SELECTED = "NOT_SELECTED";
	public static final String RIGHT = "RIGHT";
	public static final String WRONG = "WRONG";

	@NotNull
	private char character;
	
	@NotBlank
	private String status;

	public AlphabetaExerciseIProgress() {
		// TODO Auto-generated constructor stub
	}

	public char getCharacter() {
		return character;
	}
	
	public int getCharacterAscii() {
		return character;
	}

	public void setCharacter(char character) {
		this.character = character;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
