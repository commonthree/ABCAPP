package com.app.model;

import com.app.repository.entity.User;

public class Teacher extends User {
	
	public Teacher() {}

	public Teacher(User user) {
		this.setId(user.getId());
		this.setUsername(user.getUsername());
		this.setFirstName(user.getFirstName());
		this.setLastName(user.getLastName());
		this.setEmail(user.getEmail());
		this.setActive(user.getActive());
		this.setLastLogin(user.getLastLogin());
		this.setRoles(user.getRoles());
	}

}
