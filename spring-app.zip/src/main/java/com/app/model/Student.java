package com.app.model;

import java.util.ArrayList;
import java.util.List;

import com.app.repository.entity.Course;
import com.app.repository.entity.User;

public class Student extends User {

	private List<GuardianShip> guardianShips;
	private List<Course> courses;
	
	public Student() {
		super();
	}
	
	public Student(Long id) {
		this.setId(id);
	}
	
	public Student(Long id, String firstName, String lastName) {
		this(id);
		this.setFirstName(firstName);
		this.setLastName(lastName);
	}

	public Student(User user) {
		this.setId(user.getId());
		this.setUsername(user.getUsername());
		this.setFirstName(user.getFirstName());
		this.setLastName(user.getLastName());
		this.setEmail(user.getEmail());
		this.setActive(user.getActive());
		this.setLastLogin(user.getLastLogin());
		this.setRoles(user.getRoles());
	}

	public List<GuardianShip> getGuardianShips() {
		if(this.guardianShips == null)
			this.guardianShips = new ArrayList<>();
		return guardianShips;
	}

	public void setGuardianShips(List<GuardianShip> guardianShips) {
		this.guardianShips = guardianShips;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

}
