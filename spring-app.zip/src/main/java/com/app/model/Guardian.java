package com.app.model;

import java.util.ArrayList;
import java.util.List;

import com.app.repository.entity.User;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Guardian extends User {
	
	private List<GuardianShip> guardianShips;
	
	public Guardian() {}
	
	public Guardian(Long id) {
		this.setId(id);
	}
	
	public Guardian(Long id, String firstName, String lastName) {
		this(id);
		this.setFirstName(firstName);
		this.setLastName(lastName);
	}

	public Guardian(User user) {
		this.setId(user.getId());
		this.setUsername(user.getUsername());
		this.setFirstName(user.getFirstName());
		this.setLastName(user.getLastName());
		this.setEmail(user.getEmail());
		this.setActive(user.getActive());
		this.setLastLogin(user.getLastLogin());
		this.setRoles(user.getRoles());
	}

	public List<GuardianShip> getGuardianShips() {
		if (guardianShips == null) {
			this.guardianShips = new ArrayList<>();
		}
		return guardianShips;
	}

	public void setGuardianShips(List<GuardianShip> guardianShips) {
		this.guardianShips = guardianShips;
	}

}
