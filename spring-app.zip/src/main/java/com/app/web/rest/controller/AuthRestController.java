package com.app.web.rest.controller;

import javax.mail.MessagingException;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.service.UserService;
import com.app.throwable.EmailNotFoundException;
import com.app.throwable.InvalidTokenException;
import com.app.web.model.AuthRequest;
import com.app.web.model.AuthResponse;
import com.app.web.model.ForgotPasswordRequest;
import com.app.web.model.RegisterUserRequest;
import com.app.web.model.ResetPasswordRequest;
import com.app.web.security.model.AppUserDetails;
import com.app.web.security.util.JwtTokenUtil;

import io.jsonwebtoken.ExpiredJwtException;

@RestController
@RequestMapping("/auth")
public class AuthRestController {

	private static final Logger logger = LoggerFactory.getLogger(AuthRestController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@PostMapping("/authenticate")
	public AuthResponse authenticate(@Valid @RequestBody AuthRequest authRequest) {
		logger.debug("authenticationRequest: {}", authRequest);
		Authentication authenticate = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));
		if (authenticate.getPrincipal() == null || !(authenticate.getPrincipal() instanceof AppUserDetails)) {
			throw new UsernameNotFoundException(String.format("email %s not found", authRequest.getEmail()));
		}
		AppUserDetails userDetails = (AppUserDetails) authenticate.getPrincipal();
		this.userService.updateLastLogin(userDetails.getId());
		String token = jwtTokenUtil.generateToken(userDetails);
		return new AuthResponse(token);
	}

	@PostMapping("/register")
	public ResponseEntity<?> register(@Valid @RequestBody RegisterUserRequest registerUserRequest) {
		logger.debug("AuthRequest: {}", registerUserRequest);
		User user = new User();
		user.setUsername(registerUserRequest.getEmail());
		user.setEmail(registerUserRequest.getEmail());
		user.setPassword(registerUserRequest.getPassword());
		user.getRoles().add(Role.valueOf(registerUserRequest.getRole()));
		this.userService.register(user);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping("/password/forgot")
	public ResponseEntity<?> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request)
			throws EmailNotFoundException, MessagingException {
		logger.debug("ForgotPasswordRequest.email: {}", request.getEmail());
		this.userService.forgotPassword(request.getEmail());
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping("/password/reset/{token}")
	public ResponseEntity<?> resetPassword(@PathVariable String token, @Valid @RequestBody ResetPasswordRequest request)
			throws InvalidTokenException, MessagingException {
		logger.debug("token: {}, resetPasswordRequest", token, request);
		this.userService.resetPassword(token, request.getPassword());
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping("/istokenvalid")
	public ResponseEntity<Boolean> isTokenValid(@RequestParam("token") String token)
			throws InvalidTokenException, MessagingException {
		try {
			return new ResponseEntity<>(this.jwtTokenUtil.getUsernameFromToken(token) != null, HttpStatus.OK);
		} catch (ExpiredJwtException e) {
			return new ResponseEntity<>(Boolean.FALSE, HttpStatus.OK);
		}
	}

}
