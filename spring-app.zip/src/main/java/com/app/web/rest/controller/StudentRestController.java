package com.app.web.rest.controller;

import java.util.Map;

import javax.mail.MessagingException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Guardian;
import com.app.model.GuardianShip;
import com.app.model.Page;
import com.app.model.PersonRelation;
import com.app.model.Student;
import com.app.model.Teacher;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.service.StudentService;
import com.app.service.UserService;
import com.app.web.model.StudentRequest;
import com.app.web.model.UserRequest;

import io.jsonwebtoken.lang.Collections;

@RestController
@RequestMapping("/secure/api/students")
public class StudentRestController {

	@Autowired
	private StudentService studentService;

	@Autowired
	private UserService userService;

	@GetMapping()
	public ResponseEntity<Page<Student>> getStudents(
			@RequestParam(name = "filters", required = false) Map<String, String> filters,
			@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
			@RequestParam(name = "sortOrder", defaultValue = "asc") String sortOrder,
			@RequestParam(name = "pageNumber", defaultValue = "1") int pageNumber,
			@RequestParam(name = "pageSize", defaultValue = "10") int pageSize) {
		
		User user = this.userService.getUserByUsernameOrEmail();
		if(user != null && Collections.containsInstance(user.getRoles(), Role.GUARDIAN)) {
			return new ResponseEntity<Page<Student>>(
					this.studentService.getGuardianStudents(user.getId(), pageNumber, pageSize), HttpStatus.OK);
		}
		return new ResponseEntity<Page<Student>>(
				this.studentService.getStudents(filters, sortBy, sortOrder, pageNumber, pageSize), HttpStatus.OK);
	}
	
	@GetMapping("/course/{courseId}")
	public ResponseEntity<Page<Student>> getStudentsByCourse(
			@PathVariable("courseId") Long courseId,
			@RequestParam(name = "filters", required = false) Map<String, String> filters,
			@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
			@RequestParam(name = "sortOrder", defaultValue = "asc") String sortOrder,
			@RequestParam(name = "pageNumber", defaultValue = "1") int pageNumber,
			@RequestParam(name = "pageSize", defaultValue = "10") int pageSize) {
		
		return new ResponseEntity<Page<Student>>(
				this.studentService.getStudentsByCourse(pageNumber, pageSize, courseId), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Student> get(@PathVariable("id") Long id) {
		return new ResponseEntity<Student>(this.studentService.get(id), HttpStatus.OK);
	}
	
	@GetMapping("/{id}/edit")
	public ResponseEntity<Student> getForm(@PathVariable("id") Long id) {
		User user = this.userService.getUserByUsernameOrEmail();
		if(user != null && Collections.containsInstance(user.getRoles(), Role.GUARDIAN))
			return new ResponseEntity<Student>(this.studentService.getByStudentAndGuardianId(id, user.getId()), HttpStatus.OK);
		return new ResponseEntity<Student>(this.studentService.get(id), HttpStatus.OK);
	}

	@PostMapping()
	public ResponseEntity<Student> update(@RequestBody @Valid StudentRequest studentRequest) throws MessagingException {
		Student student = new Student();
		student.setId(studentRequest.getId());
		student.setFirstName(studentRequest.getFirstName());
		student.setLastName(studentRequest.getLastName());
		student.setUsername(studentRequest.getUsername());
		student.setEmail(studentRequest.getEmail());
		student.setActive(studentRequest.getActive());
		student.getRoles().add(Role.STUDENT);
		student.getGuardianShips().add(
				new GuardianShip(new Guardian(this.userService.getUserByUsernameOrEmail()), 
						new PersonRelation(studentRequest.getRelationId())));
		return new ResponseEntity<Student>(this.userService.updateStudent(student), HttpStatus.OK);
	}

}
