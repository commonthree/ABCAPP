package com.app.web.rest.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.AlphabetaExerciseIProgress;
import com.app.model.CharacterView;
import com.app.model.NumberView;
import com.app.model.Page;
import com.app.repository.entity.Course;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.service.CourseService;
import com.app.service.UserService;

@RestController
@RequestMapping("/secure/api/courses")
public class CourseRestController {

	@Autowired
	private CourseService courseService;
	
	@Autowired
	private UserService userService;

	@GetMapping()
	public Page<Course> getCoursePage(
			@RequestParam(name = "pageNumber", defaultValue = "1") int pageNumber,
			@RequestParam(name = "pageSize", defaultValue = "10") int pageSize) {
		return this.courseService.getCourses(pageNumber, pageSize, this.userService.getUserByUsernameOrEmail());
	}
	
	@GetMapping("/my")
	public Page<Course> getMyCourses(@RequestParam(name = "pageNumber", defaultValue = "1") int pageNumber,
			@RequestParam(name = "pageSize", defaultValue = "10") int pageSize) {
		return this.courseService.getByEnrolledUserId(pageNumber, pageSize, this.userService.getUserByUsernameOrEmail().getId());
	}
	
	@PostMapping("/enroll")
	public Course enroll(@RequestBody Long courseId) {
		User user = this.userService.getUserByUsernameOrEmail();
		return this.courseService.enroll(user.getId(), courseId);
	}
	
	
	@GetMapping("/alphabet/{id}")
	public Course getAlphabetCourse(@PathVariable("id") Long id) {
		return this.courseService.getAlphabetByCourseId(id, this.userService.getUserByUsernameOrEmail().getId());
	}
	
	@GetMapping("/alphabet/{id}/exercise-i")
	public Course getAlphabetExerciseI(@PathVariable("id") Long id, @RequestParam(name = "replay", defaultValue = "false") boolean replay) {
		return this.courseService.getAlphabetCourseExerciseI(id, this.userService.getUserByUsernameOrEmail().getId(), replay);
	}
	
	@GetMapping("/alphabet/{id}/exercise-i/progress/{userId}")
	public List<Course> getAlphabetExerciseIProgress(@PathVariable("id") Long id, @PathVariable(name = "userId", required = false) Long userId) {
		return this.courseService.getAlphabetCourseExerciseIProgress(id, userId);
	}
	
	@GetMapping("/alphabet/{id}/exercise-i/progress")
	public List<Course> getAlphabetExerciseIProgress(@PathVariable("id") Long id) {
		return this.courseService.getAlphabetCourseExerciseIProgress(id, this.userService.getUserByUsernameOrEmail().getId());
	}
	
	@PostMapping("/alphabet/{id}/exercise-i")
	public Course setAlphabetExerciseIProgress(@PathVariable("id") Long id, @RequestBody @Valid AlphabetaExerciseIProgress alphabetaStudentProgress) {
		User user = this.userService.getUserByUsernameOrEmail();
		if(user.getRoles() != null && user.getRoles().contains(Role.STUDENT)) {
			return this.courseService.setAlphabetCourseExerciseI(id, user.getId(), alphabetaStudentProgress);
		}
		return null;
	}
	
	
	@GetMapping("/alphabet/{id}/{character}")
	public CharacterView getAlphabetCourse(@PathVariable("id") Long id, @PathVariable("character") char c) {
		return this.courseService.getCharacterView(c);
	}
	
	@GetMapping("/number/{id}")
	public Course getNumberCourse(@PathVariable("id") Long id) {
		return this.courseService.getNumberByCourseId(id, this.userService.getUserByUsernameOrEmail().getId());
	}
	
	@GetMapping("/number/{id}/{number}")
	public NumberView getNumberCourse(@PathVariable("id") Long id, @PathVariable("number") Number number) {
		return this.courseService.getNumberView(id, number);
	}
	
	@GetMapping("/{id}")
	public Course getCourse(@PathVariable("id") Long id) {
		return this.courseService.getCourse(id, this.userService.getUserByUsernameOrEmail().getId());
	}
	
	@GetMapping("/student/{id}")
	public List<Course> getCoursesByStudentId(@PathVariable("id") Long id){
		return this.courseService.getCourseByStudentId(id);
	}
}
