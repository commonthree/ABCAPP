package com.app.web.rest.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.service.UserRoleService;

@RestController
@RequestMapping(value = "/public/api/user/roles")
public class UserRoleRestController {

	@Autowired
	private UserRoleService userRoleService;

	@GetMapping()
	public List<HashMap<Object, Object>> getRoles() {
		return this.userRoleService.getRoles();
	}
	
	@GetMapping("/registeration")
	public List<HashMap<Object, Object>> getRolesForRegistration() {
		return this.userRoleService.getRolesForRegistration();
	}
	
	@PostMapping("/{userId}")
	public ResponseEntity<Object> addUserRoles(@PathVariable(name = "userId") Long userId, @RequestBody(required = true) String[] roles) {
		int i = this.userRoleService.addUserRoles(userId, roles);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
	
	@DeleteMapping("/{userId}")
	public ResponseEntity<Object> removeUserRoles(@PathVariable(name = "userId") Long userId, @RequestParam(required = true, name = "roles") String[] roles) {
		int i = this.userRoleService.removeUserRoles(userId, roles);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
		
}
