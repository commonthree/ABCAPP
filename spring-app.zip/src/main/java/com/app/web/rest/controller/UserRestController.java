package com.app.web.rest.controller;

import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Guardian;
import com.app.model.Page;
import com.app.model.Student;
import com.app.model.Teacher;
import com.app.repository.entity.User;
import com.app.service.StudentService;
import com.app.service.UserService;
import com.app.web.model.UserRequest;

@RestController
@RequestMapping("/secure/api/users")
public class UserRestController {

	@Autowired
	private UserService userService;

	@GetMapping("/")
	public List<User> getAll() {
		return null;
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getByUsername(@PathVariable("id") Long id) {
		return new ResponseEntity<User>(this.userService.get(id), HttpStatus.OK);
	}

	@GetMapping("/currentuser")
	public ResponseEntity<User> getAuthenticatedUser() {
		return new ResponseEntity<User>(this.userService.getUserByUsernameOrEmail(), HttpStatus.OK);
	}

	@PostMapping()
	public ResponseEntity<User> update(@RequestBody UserRequest userRequest) throws MessagingException {
		User user = new User();
		user.setId(userRequest.getId());
		user.setFirstName(userRequest.getFirstName());
		user.setLastName(userRequest.getLastName());
		user.setUsername(userRequest.getUsername());
		user.setEmail(userRequest.getEmail());
		user.setActive(userRequest.getActive());
		return new ResponseEntity<User>(this.userService.update(user), HttpStatus.OK);
	}

//	@GetMapping("/teachers")
//	public ResponseEntity<Page<Teacher>> getTeachers(@RequestParam("pageNumber") int pageNumber, @RequestParam("pageSize") int pageSize) {
//		return new ResponseEntity<Page<Teacher>>(this.userService.getTeachers(pageNumber, pageSize), HttpStatus.OK);
//	}
//	
//	@GetMapping("/guardians")
//	public ResponseEntity<Page<Guardian>> getGuardians(@RequestParam("pageNumber") int pageNumber, @RequestParam("pageSize") int pageSize) {
//		return new ResponseEntity<Page<Guardian>>(this.userService.getGuardians(pageNumber, pageSize), HttpStatus.OK);
//	}

}
