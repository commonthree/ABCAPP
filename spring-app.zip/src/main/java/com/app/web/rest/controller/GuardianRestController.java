package com.app.web.rest.controller;

import java.util.Map;

import javax.mail.MessagingException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Admin;
import com.app.model.Guardian;
import com.app.model.Page;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.service.AdminService;
import com.app.service.GuardianService;
import com.app.service.UserService;
import com.app.web.model.UserRequest;

import io.jsonwebtoken.lang.Collections;

@RestController
@RequestMapping("/secure/api/guardians")
public class GuardianRestController {

	@Autowired
	private GuardianService guardianService;

	@Autowired
	private UserService userService;

	@GetMapping()
	public ResponseEntity<Page<Guardian>> getGuardians(
			@RequestParam(name = "filters", required = false) Map<String, String> filters,
			@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
			@RequestParam(name = "sortOrder", defaultValue = "asc") String sortOrder,
			@RequestParam(name = "pageNumber", defaultValue = "1") int pageNumber,
			@RequestParam(name = "pageSize", defaultValue = "10") int pageSize) {
		
		User user = this.userService.getUserByUsernameOrEmail();
		
		if(user != null && Collections.containsInstance(user.getRoles(), Role.STUDENT)) {
			return new ResponseEntity<Page<Guardian>>(
					this.guardianService.getGuardiansByStudentId(user.getId(), pageNumber, pageSize), HttpStatus.OK);			
		}
		
		return new ResponseEntity<Page<Guardian>>(
				this.guardianService.getGuardians(filters, sortBy, sortOrder, pageNumber, pageSize), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Guardian> get(@PathVariable("id") Long id) {
		return new ResponseEntity<Guardian>(this.guardianService.get(id), HttpStatus.OK);
	}

	@PostMapping()
	public ResponseEntity<User> update(@RequestBody @Valid UserRequest userRequest) throws MessagingException {
		User user = new User();
		user.setId(userRequest.getId());
		user.setFirstName(userRequest.getFirstName());
		user.setLastName(userRequest.getLastName());
		user.setUsername(userRequest.getUsername());
		user.setEmail(userRequest.getEmail());
		user.setActive(userRequest.getActive());
		user.getRoles().add(Role.GUARDIAN);
		return new ResponseEntity<User>(this.userService.update(user), HttpStatus.OK);
	}

}
