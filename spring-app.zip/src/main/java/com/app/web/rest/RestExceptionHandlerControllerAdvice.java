package com.app.web.rest;

import java.sql.SQLIntegrityConstraintViolationException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.app.throwable.EmailNotFoundException;
import com.app.throwable.InvalidTokenException;
import com.app.throwable.UserEmailAlreadyExistsException;
import com.app.web.model.AppErrorRestResponse;

@RestControllerAdvice
public class RestExceptionHandlerControllerAdvice {
	private static final Logger logger = LoggerFactory.getLogger(RestExceptionHandlerControllerAdvice.class);

	@ExceptionHandler(value = { UsernameNotFoundException.class })
	public ResponseEntity<AppErrorRestResponse> handleUsernameNotFoundException(HttpServletRequest req,
			UsernameNotFoundException ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.UNAUTHORIZED, "Authentication Failure");
	}

	@ExceptionHandler(value = { BadCredentialsException.class })
	public ResponseEntity<AppErrorRestResponse> handleBadCredentialsException(HttpServletRequest req,
			BadCredentialsException ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.UNAUTHORIZED, "Authentication Failure");
	}

	@ExceptionHandler(value = { UserEmailAlreadyExistsException.class })
	public ResponseEntity<AppErrorRestResponse> handleUserEmailAlreadyExistsException(HttpServletRequest req,
			Exception ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.INTERNAL_SERVER_ERROR, "Email already registered");
	}

	@ExceptionHandler(value = { EmailNotFoundException.class })
	public ResponseEntity<AppErrorRestResponse> handleEmailNotFoundException(HttpServletRequest req,
			EmailNotFoundException ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.INTERNAL_SERVER_ERROR, "Email not found");
	}

	@ExceptionHandler(value = { MethodArgumentNotValidException.class })
	public void handleMethodArgumentNotValidException(HttpServletRequest req, MethodArgumentNotValidException ex)
			throws MethodArgumentNotValidException {
		logError(ex);
		throw ex;
	}

	@ExceptionHandler(value = { InvalidTokenException.class })
	public ResponseEntity<AppErrorRestResponse> handleInvalidTokenException(HttpServletRequest req,
			InvalidTokenException ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.INTERNAL_SERVER_ERROR, "Invalid Token");
	}

	@ExceptionHandler(value = { DuplicateKeyException.class })
	public ResponseEntity<AppErrorRestResponse> handleException(HttpServletRequest req,
			DuplicateKeyException ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.INTERNAL_SERVER_ERROR, ex.getClass().getSimpleName());
	}
	
	@ExceptionHandler(value = { SQLIntegrityConstraintViolationException.class })
	public ResponseEntity<AppErrorRestResponse> handleException(HttpServletRequest req,
			SQLIntegrityConstraintViolationException ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.INTERNAL_SERVER_ERROR, "SQL Constraints Validation Exception");
	}

	@ExceptionHandler(value = { Exception.class })
	public ResponseEntity<AppErrorRestResponse> handleException(HttpServletRequest req, Exception ex) {
		logError(ex);
		return getResponseEntity(req, ex, HttpStatus.INTERNAL_SERVER_ERROR, "Internal Server error");
	}

	private ResponseEntity<AppErrorRestResponse> getResponseEntity(HttpServletRequest req, Exception ex,
			HttpStatus httpStatus, String error) {
		return new ResponseEntity<>(
				new AppErrorRestResponse(httpStatus.value(), error, ex.getMessage(), req.getServletPath()), httpStatus);
	}

	private void logError(Exception ex) {
		logger.error(ex.getClass().getSimpleName(), ex);
	}
}
