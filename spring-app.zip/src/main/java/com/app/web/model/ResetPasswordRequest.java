package com.app.web.model;

import javax.validation.constraints.NotBlank;

public class ResetPasswordRequest {

	@NotBlank(message = "password is required")
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
