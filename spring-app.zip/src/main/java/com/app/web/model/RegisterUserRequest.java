package com.app.web.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@NotNull
public class RegisterUserRequest {

	@NotEmpty(message = "email field is required")
	@Email(message = "invalid email format")
	private String email;

	@NotEmpty(message = "password field is required")
	@Size(min = 8, max = 12, message = "password character should be between 8 to 12 characters")
	private String password;
	
	@NotEmpty(message = "role field is required")
	private String role;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
