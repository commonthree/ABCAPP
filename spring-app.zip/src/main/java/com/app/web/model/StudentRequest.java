package com.app.web.model;

import javax.validation.constraints.NotNull;

public class StudentRequest extends UserRequest {

	@NotNull
	private Integer relationId;

	public Integer getRelationId() {
		return relationId;
	}

	public void setRelationId(Integer relationId) {
		this.relationId = relationId;
	}
}
