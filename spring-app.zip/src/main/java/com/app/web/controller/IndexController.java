package com.app.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class IndexController {

//	@RequestMapping(value = {"/", "/{page}"})
	public String index(@PathVariable(name = "page", required = false, value = "") String page) {
		return "index";
	}
}
