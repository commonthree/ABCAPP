package com.app.web.security.service;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.repository.UserRepository;
import com.app.repository.UserRoleRepository;
import com.app.repository.entity.User;
import com.app.web.security.model.AppUserDetails;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Override
	public AppUserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = this.userRepository.getUserByUsernameOrEmail(username);
		if (user == null) {
			throw new UsernameNotFoundException(String.format("email '%s' not found.", username));
		}
		user.setRoles(userRoleRepository.getRolesByUserId(user.getId()).stream().collect(Collectors.toList()));
		return new AppUserDetails(user);
	}

}
