package com.app.web.security.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.app.repository.entity.Role;
import com.app.repository.entity.User;

public class AppUserDetails extends org.springframework.security.core.userdetails.User {

	private Long id;
	private String email;

	public AppUserDetails(User user) {
		super(user.getUsername() == null ? user.getEmail(): user.getUsername(), user.getPassword(), getGrantedAuthorities(user.getRoles()));
		this.id = user.getId();
		this.email = user.getEmail();
	}

	private static Collection<? extends GrantedAuthority> getGrantedAuthorities(List<Role> roles) {
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		if(roles != null) {
			for(Role role: roles) {
				grantedAuthorities.add(new SimpleGrantedAuthority(role.name()));
			}
		}
		return grantedAuthorities;
	}

	public AppUserDetails(String username, String password, boolean enabled, boolean accountNonExpired,
			boolean credentialsNonExpired, boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities) {
		super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
