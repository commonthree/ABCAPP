package com.app.repository;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.app.model.PersonRelation;
import com.app.repository.util.JdbcTemplateUtil;

@Repository
public class PersonRelationRepository {

	private static final String SELECT_PERSON_RELATION = "select * from person_relation";

	private static final String SELECT_PR_BY_STUDENT_AND_GUARDIAN_ID = "select pr.id, pr.name from person_relation pr"
			+ " join student_guardian sg on sg.relation_id = pr.id"
			+ " where sg.student_user_id = ? and sg.guardian_user_id = ?";

	@Autowired
	private JdbcTemplateUtil jdbcTemplateUtil;
	RowMapper<PersonRelation> rowMapper = (rs, rowNum) -> new PersonRelation(rs.getInt("id"), rs.getString("name"));

	public List<PersonRelation> getAll() {
		return jdbcTemplateUtil.queryList(SELECT_PERSON_RELATION, rowMapper).stream().collect(Collectors.toList());
	}

	public PersonRelation getByStudentAndGuardianId(Long studentId, Long guardianId) {
		return jdbcTemplateUtil.queryOne(SELECT_PR_BY_STUDENT_AND_GUARDIAN_ID, rowMapper, studentId, guardianId);
	}
}
