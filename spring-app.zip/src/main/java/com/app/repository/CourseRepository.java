package com.app.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.model.AlphabetaExerciseI;
import com.app.model.AlphabetaExerciseIProgress;
import com.app.model.Page;
import com.app.repository.entity.Alphabeta;
import com.app.repository.entity.Course;
import com.app.repository.entity.jdbc.rowmapper.AlphabetaExerciseIRowMapper;
import com.app.repository.entity.jdbc.rowmapper.AlphabetaRowMapper;
import com.app.repository.entity.jdbc.rowmapper.AlphabetaStatusRowMapper;
import com.app.repository.entity.jdbc.rowmapper.AlphabetaWrongCountRowMapper;
import com.app.repository.entity.jdbc.rowmapper.CourseRowMapper;
import com.app.repository.entity.jdbc.rowmapper.CourseSessionRowMapper;
import com.app.repository.entity.jdbc.rowmapper.EnrolledCourseRowMapper;
import com.app.repository.entity.jdbc.rowmapper.NumberRowMapper;
import com.app.repository.util.JdbcTemplateUtil;

@Repository
public class CourseRepository {
	
	private static final String GET_ALL_COURSES = "select c.id, c.`key`, c.title from course c";

	private static final String GET_ALL_COURSES_WITH_ENROLLMENT = "select c.id, c.`key`, c.title, sc.enrolled as enrolled"
			+ " from course c"
			+ " left join (select sc.course_id, true as enrolled from student_course sc where sc.user_id = ? ) as sc on sc.course_id = c.id";

	private static final String GET_COURSE_BY_ID = "select * from course c where c.id = ? ";

	private static final String GET_ALPHABETA_BY_COURSE_ID = "select * from alphabeta a where a.course_id = ? and a.char_case = 'CAPITAL'";

	private static final String GET_ENROLLED_COURSES_BY_USER_ID = "select * from student_course sc left join course c on c.id = sc.course_id where sc.user_id = ? ";

	private static final String ENROLL_USER_AND_COURSE = "insert student_course(user_id, course_id) values (?, ?)";

	private static final String GET_COURSE_BY_ID_AND_USER_ID = "select c.id, c.`key`, c.title, if(sc.user_id = ?, true, false) as enrolled "
			+ "from course c "
			+ "left join student_course sc on sc.course_id = c.id "
			+ "where c.id = ?";

	private static final String GET_COURSE_BY_STUDENT_ID = "select * from student_course sc"
			+ " left join course c on c.id = sc.course_id "
			+ " where sc.user_id = ?";

	private static final String GET_ALPHABET_EXERCISE_SESSION = "select * from alphabeta_exercise_i"
			+ " where course_id = ? and student_id = ?"
			+ " order by session_id desc"
			+ " limit 0,1";

	private static final String INSERT_ALPHABET_EXERCISE_I = "insert into alphabeta_exercise_i(course_id, student_id)"
			+ " values (?, ?)";

	private static final String INSERT_ALPHABET_EXERCISE_I_PROGRESS = "insert into alphabeta_exercise_i_progress(session_id, character_ascii, wrong_count, status)"
			+ " values (?, ?, ?, ?) ON DUPLICATE KEY UPDATE wrong_count = wrong_count  + ?, status = ?";

	private static final String GET_ALPHABETA_WITH_EXERCISE_I_PROGRESS_BY_COURSE_ID_AND_SESSION_ID = "select *"
			+ " from alphabeta a"
			+ " left join (select * from alphabeta_exercise_i_progress aeip where aeip.session_id = ?) as aeip"
			+ " on aeip.character_ascii = a.character_ascii where a.course_id = ? and a.char_case = 'CAPITAL'";

	private static final String GET_ALPHABETA_WITH_EXERCISE_I_SESSION_COURSE_ID_AND_STUDENT_ID = "select * from alphabeta_exercise_i aei"
			+ " left join course c on c.id = aei.course_id "
			+ " where aei.course_id = ? and aei.student_id = ?"
			+ " order by aei.session_id desc";

	private static final String GET_ALPHABETA_WITH_EXERCISE_I_PROGRESS_BY_SESSION_ID = "select *"
			+ " from alphabeta a"
			+ " left join (select * from alphabeta_exercise_i_progress aeip where aeip.session_id = ?) as aeip"
			+ " on aeip.character_ascii = a.character_ascii"
			+ " where a.char_case = 'CAPITAL'";


	@Autowired
	private JdbcTemplateUtil jdbcTemplateUtil;
	
	public Page<Course> getCourses(Page<Course> page) {
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_ALL_COURSES));
		page.setItems(jdbcTemplateUtil.queryPage(GET_ALL_COURSES, new CourseRowMapper(), page));
		return page;
	}

	public Page<Course> getCourses(Page<Course> page, Long userId) {
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_ALL_COURSES_WITH_ENROLLMENT, userId));
		page.setItems(jdbcTemplateUtil.queryPage(GET_ALL_COURSES_WITH_ENROLLMENT, new EnrolledCourseRowMapper(), page, userId));
		return page;
	}

	public Course getCourse(Long id) {
		return jdbcTemplateUtil.queryOne(GET_COURSE_BY_ID, new CourseRowMapper(), id);
	}

	public List<Alphabeta> getAlphabetaListByCourseId(Long id) {
		return jdbcTemplateUtil.queryList(GET_ALPHABETA_BY_COURSE_ID, new AlphabetaRowMapper(), id);
	}

	public Page<Course> getByEnrolledUserId(Page<Course> page, Long id) {
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_ENROLLED_COURSES_BY_USER_ID, id));
		page.setItems(jdbcTemplateUtil.queryPage(GET_ENROLLED_COURSES_BY_USER_ID, new CourseRowMapper(), page, id));
		return page;
	}

	public int enroll(Long userId, Long courseId) {
		return jdbcTemplateUtil.updateAndGetUpdateCount(ENROLL_USER_AND_COURSE, userId, courseId);
	}

	public Course getCourse(Long courseId, Long userId) {
		return jdbcTemplateUtil.queryOne(GET_COURSE_BY_ID_AND_USER_ID, new EnrolledCourseRowMapper(), userId, courseId);
	}

	public List<Course> getCourseByStudentId(Long id) {
		return jdbcTemplateUtil.queryList(GET_COURSE_BY_STUDENT_ID, new CourseRowMapper(), id);
	}

	public AlphabetaExerciseI getAlphabetExerciseSession(Long courseId, Long userId) {
		return jdbcTemplateUtil.queryOne(GET_ALPHABET_EXERCISE_SESSION, new AlphabetaExerciseIRowMapper(), courseId, userId);
	}
	
	public Long createAlphabetExerciseSession(Long courseId, Long userId) {
		return jdbcTemplateUtil.updateAndGetId(INSERT_ALPHABET_EXERCISE_I, courseId, userId).longValue();
	}

	public int setAlphabetExerciseIProgress(Long sessionId, Integer characterAscii, String status) {
		int wrongCount = status.equals(AlphabetaExerciseIProgress.WRONG)?1:0;
		return jdbcTemplateUtil.updateAndGetUpdateCount(INSERT_ALPHABET_EXERCISE_I_PROGRESS, sessionId, characterAscii, wrongCount, status, wrongCount, status);
	}

	public List<Alphabeta> getAlphabetExerciseI(Long courseId, Long sessionId) {
		return jdbcTemplateUtil.queryList(GET_ALPHABETA_WITH_EXERCISE_I_PROGRESS_BY_COURSE_ID_AND_SESSION_ID, new AlphabetaStatusRowMapper(), sessionId, courseId);
	}

	public List<Alphabeta> getAlphabetCourseExerciseIProgress(Long sessionId) {
		return jdbcTemplateUtil.queryList(GET_ALPHABETA_WITH_EXERCISE_I_PROGRESS_BY_SESSION_ID, new AlphabetaWrongCountRowMapper(), sessionId);
	}

	public List<Course> getAlphabetCourseExerciseISessions(Long courseId, Long userId) {
		return jdbcTemplateUtil.queryList(GET_ALPHABETA_WITH_EXERCISE_I_SESSION_COURSE_ID_AND_STUDENT_ID,
				new CourseSessionRowMapper(), courseId, userId);
	}


}
