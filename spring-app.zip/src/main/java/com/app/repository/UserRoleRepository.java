package com.app.repository;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.app.repository.entity.Role;
import com.app.repository.util.JdbcTemplateUtil;

@Repository
public class UserRoleRepository {

	private static final Logger logger = LoggerFactory.getLogger(UserRoleRepository.class);

	private static final String GET_USER_ROLE_BY_USER_ID = "select ur.role_key from user_role ur "
			+ " join role r on r.key = ur.role_key "
			+ " where ur.user_id = ? order by r.id";

	private static final String GET_USER_ROLE = "select r.key from role r";

	private static final String GET_USER_ROLE_FOR_REGISTRATION = "select r.key from role r where r.key in ('GUARDIAN', 'STUDENT', 'TEACHER')";

	private static final String INSERT_USER_ROLE = "insert into user_role (user_id, role_key) values (?, ?)";

	private static final String DELETE_USER_ROLES = "delete from user_role where user_id = ? and role_key = ? ";

	@Autowired
	private JdbcTemplateUtil jdbcTemplateUtil;

	private RowMapper<Role> userRoleMapper = (rs, rowNum) -> {
		try {
			return Role.valueOf(rs.getString("role_key"));
		} catch (Exception e) {
			logger.error("exception occured in RowMapper<Role>: ", e);
			return null;
		}
	};
	
	private RowMapper<Role> roleMapper = (rs, rowNum) -> {
		try {
			return Role.valueOf(rs.getString("key"));
		} catch (Exception e) {
			logger.error("exception occured in RowMapper<Role>: ", e);
			return null;
		}
	};

	public int insertUserRole(Long userId, Role role) {
		return jdbcTemplateUtil.updateAndGetUpdateCount(INSERT_USER_ROLE, userId, role.toString());
	}
	
	public int insertUserRoles(Long userId, String[] roles) {
		int i = 0;
		for (int j = 0; j < roles.length; j++) {
			i += jdbcTemplateUtil.updateAndGetUpdateCount(INSERT_USER_ROLE, userId, roles[j]);
		}
		return i;
	}

	public int deleteUserRoles(Long userId, String[] roles) {
		int i = 0;
		for (int j = 0; j < roles.length; j++) {
			i += jdbcTemplateUtil.updateAndGetUpdateCount(DELETE_USER_ROLES, userId, roles[j]);			
		}
		return i;
	}
	
	public Collection<Role> getRolesByUserId(Long userId) {
		return jdbcTemplateUtil.queryList(GET_USER_ROLE_BY_USER_ID, userRoleMapper, userId);
	}

	public Collection<Role> getRoles() {
		return jdbcTemplateUtil.queryList(GET_USER_ROLE, roleMapper);
	}

	public Collection<? extends Role> getRolesForRegistration() {
		return jdbcTemplateUtil.queryList(GET_USER_ROLE_FOR_REGISTRATION, roleMapper);
	}

}
