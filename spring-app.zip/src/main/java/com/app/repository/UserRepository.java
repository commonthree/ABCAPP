package com.app.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.app.model.Guardian;
import com.app.model.Page;
import com.app.model.Student;
import com.app.repository.entity.Role;
import com.app.repository.entity.User;
import com.app.repository.entity.jdbc.rowmapper.AuthUserRowMapper;
import com.app.repository.entity.jdbc.rowmapper.GuardianDetailRowMapper;
import com.app.repository.entity.jdbc.rowmapper.StudentDetailRowMapper;
import com.app.repository.entity.jdbc.rowmapper.UserDetailRowMapper;
import com.app.repository.util.JdbcTemplateUtil;

@Repository
public class UserRepository {

	private static final String SELECT_USER = "select u.id, u.username, u.email, u.first_name, u.last_name, u.active"
			+ " from `user` as u ";
	private static final String GET_USER_BY_USERNAME_OR_EMAIL = "select u.id, u.username, u.email, u.password, u.active from user u where u.username = ? or u.email = ? ";
	private static final String GET_USER_DETAILS_BY_USERNAME_OR_EMAIL = SELECT_USER
			.concat(" where u.username = ? or u.email = ? ");
	private static final String GET_USER_BY_EMAIL = "select u.id, u.username, u.email, u.password, u.active from user u where u.email = ? ";
//	private static final String GET_ALL_USER = "select u.id, u.username, u.email, u.password from user u ";
	private static final String REGISTER_USER = "insert user (email, password) values (?, ?) ";
	private static final String INSERT_USER = "insert user (first_name, last_name, username, email, password, active) values (?, ?, ?, ?, ?, ?) ";
	private static final String UPDATE_LAST_LOGIN_BY_USER_ID = "update user set last_login = current_timestamp() where id = ? ";
	private static final String UPDATE_RESET_PASSWORD_TOKEN_BY_USER_ID = "update user set reset_password_token = ? where id = ? ";
	private static final String GET_USER_BY_TOKEN = "select u.id, u.username, u.email, u.reset_password_token from user u where u.reset_password_token = ? ";
	private static final String UPDATE_PASSWORD_BY_USER_ID = "update user set password = ?, last_password_change_on = current_timestamp() where id = ? ";
	private static final String REMOVE_PASSWORD_RESET_TOKEN_BY_USER_ID = "update user set reset_password_token = null where id = ? ";
	private static final String GET_USERS_BY_ROLES = SELECT_USER
			.concat(" join user_role ur on ur.user_id = u.id where ur.role_key = (?)");
	private static final String GET_USER_BY_ID = SELECT_USER.concat(" where u.id = ?");
	private static final String UPDATE_USER_DETAILS = "update `user`" + " set first_name = ?," + " last_name = ?, "
			+ " username = ?, " + " email = ?, " + " active = ?" + " where id = ?";
	private static final String GET_STUDENTS_BY_GUARDIAN_ID = SELECT_USER.concat("join student_guardian sg on sg.student_user_id = u.id where sg.guardian_user_id = ? ");
	private static final String GET_STUDENTS_BY_STUDENT_ID = SELECT_USER.concat("join student_guardian sg on sg.guardian_user_id = u.id where sg.student_user_id = ? ");
	private static final String GET_STUDENTS_BY_COURSE_ID = "select * from student_course sc"
			+ " left join user u on u.id = sc.user_id"
			+ " where sc.course_id = ?";

	@Autowired
	private JdbcTemplateUtil jdbcTemplateUtil;

	public User getUserDetailsByUsernameOrEmail(String username) {
		return jdbcTemplateUtil.queryOne(GET_USER_DETAILS_BY_USERNAME_OR_EMAIL, new UserDetailRowMapper(), username,
				username);
	}

	public User getUserByUsernameOrEmail(String username) {
		return jdbcTemplateUtil.queryOne(GET_USER_BY_USERNAME_OR_EMAIL, new AuthUserRowMapper(), username, username);
	}

	public User getUserByEmail(String email) {
		return jdbcTemplateUtil.queryOne(GET_USER_BY_EMAIL, new AuthUserRowMapper(), email);
	}

	public Long register(User user) {
		return jdbcTemplateUtil.updateAndGetId(REGISTER_USER, user.getEmail(), user.getPassword()).longValue();
	}

	public Long save(User user) {
		return jdbcTemplateUtil.updateAndGetId(INSERT_USER, user.getFirstName(), user.getLastName(), user.getUsername(),
				user.getEmail(), user.getPassword(), user.getActive()).longValue();
	}

	public void updateLastLogin(Long id) {
		jdbcTemplateUtil.updateAndGetUpdateCount(UPDATE_LAST_LOGIN_BY_USER_ID, id);
	}

	public void updateResetPasswordToken(Long id, String token) {
		jdbcTemplateUtil.updateAndGetUpdateCount(UPDATE_RESET_PASSWORD_TOKEN_BY_USER_ID, token, id);
	}

	public User getUserByToken(String token) {
		return jdbcTemplateUtil.queryOne(GET_USER_BY_TOKEN, (rs, rowNum) -> {
			User user = new User();
			user.setId(rs.getLong("id"));
			user.setEmail(rs.getString("email"));
			user.setUsername(rs.getString("username"));
			user.setResetPasswordToken(rs.getString("reset_password_token"));
			return user;
		}, token);
	}

	public void updatePassword(Long id, String password) {
		int rowsUpdate = jdbcTemplateUtil.updateAndGetUpdateCount(UPDATE_PASSWORD_BY_USER_ID, password, id);
		if (rowsUpdate > 0) {
			jdbcTemplateUtil.updateAndGetUpdateCount(REMOVE_PASSWORD_RESET_TOKEN_BY_USER_ID, id);
		}
	}
	

	public <T extends User> Page<T> getUsersByRoles(Role role, Page<T> page) {
//		Object arg = new Object[] {roles};
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_USERS_BY_ROLES, role.toString()));
		page.setItems(jdbcTemplateUtil.queryPage(GET_USERS_BY_ROLES, new RowMapper<T>() {
			@Override
			public T mapRow(ResultSet rs, int rowNum) throws SQLException {
				User user = new User();
				user.setId(rs.getLong("id"));
				user.setEmail(rs.getString("email"));
				user.setUsername(rs.getString("username"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				user.setActive(rs.getBoolean("active"));
				return (T) user;
			}
		}, page, role.toString()));
		return page;
	}

	public User getUserById(Long id) {
		return this.jdbcTemplateUtil.queryOne(GET_USER_BY_ID, new UserDetailRowMapper(), id);
	}

	public User update(User user) {
		jdbcTemplateUtil.updateAndGetUpdateCount(UPDATE_USER_DETAILS, user.getFirstName(), user.getLastName(),
				user.getUsername(), user.getEmail(), user.getActive(), user.getId());
		return this.getUserById(user.getId());
	}

	public Page<Student> getStudentsByGuardianId(Long userId, Page<Student> page) {
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_STUDENTS_BY_GUARDIAN_ID, userId));
		page.setItems(jdbcTemplateUtil.queryPage(GET_STUDENTS_BY_GUARDIAN_ID, new StudentDetailRowMapper(), page, userId));
		return page;
	}

	public Page<Guardian> getGuardiansByStudentId(Long userId, Page<Guardian> page) {
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_STUDENTS_BY_STUDENT_ID, userId));
		page.setItems(jdbcTemplateUtil.queryPage(GET_STUDENTS_BY_STUDENT_ID, new GuardianDetailRowMapper(), page, userId));
		return page;
	}

	public Page<Student> getStudentsByCourse(Long courseId, Page<Student> page) {
		page.setTotalItems(jdbcTemplateUtil.queryCount(GET_STUDENTS_BY_COURSE_ID, courseId));
		page.setItems(jdbcTemplateUtil.queryPage(GET_STUDENTS_BY_COURSE_ID, new StudentDetailRowMapper(), page, courseId));
		return page;
	}

}
