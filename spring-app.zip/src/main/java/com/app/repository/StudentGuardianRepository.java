package com.app.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.app.model.Guardian;
import com.app.model.GuardianShip;
import com.app.model.PersonRelation;
import com.app.model.Student;
import com.app.repository.util.JdbcTemplateUtil;

@Repository
public class StudentGuardianRepository {

	private static final String INSERT_STUDENT_GUARDIAN = "INSERT INTO abc.student_guardian"
			+ " (guardian_user_id, student_user_id, relation_id)" + " VALUES(?, ?, ?) \n"
			+ " ON DUPLICATE KEY UPDATE relation_id = ?";
	private static final String SELECT_STUDENT_GUARDIAN = "select sg.guardian_user_id, sg.student_user_id, sg.relation_id,"
			+ " g.first_name as gfirst_name, g.last_name as glast_name," 
			+ " s.first_name as sfirst_name, s.last_name as slast_name," 
			+ " pr.name as relation_name "
			+ " from student_guardian sg "
			+ " join user g on g.id = sg.guardian_user_id "
			+ " join user s on s.id = sg.student_user_id "
			+ " join person_relation pr on pr.id = sg.relation_id ";
	
	private static final String GET_STUDENT_GUARDIAN_BY_STUDENT_ID = SELECT_STUDENT_GUARDIAN 
			+ " where sg.student_user_id = ?";
	private static final String GET_STUDENT_GUARDIAN_BY_STUDENT_AND_GUARDIAN_ID = SELECT_STUDENT_GUARDIAN 
			+ " where sg.student_user_id = ? and sg.guardian_user_id = ?";
	private static final String GET_STUDENT_GUARDIAN_BY_GUARDIAN_ID = SELECT_STUDENT_GUARDIAN
			+ " where sg.guardian_user_id = ?";

	@Autowired
	private JdbcTemplateUtil jdbcTemplateUtil;

	public int add(Long guardianId, Long studentId, Integer relationId) {
		return jdbcTemplateUtil.updateAndGetUpdateCount(INSERT_STUDENT_GUARDIAN, guardianId, studentId, relationId,
				relationId);
	}

	private RowMapper<GuardianShip> rowMapper = (rs, rowNum) -> {
		GuardianShip guardianShip = new GuardianShip();
		guardianShip.setGuardian(
				new Guardian(rs.getLong("guardian_user_id"), rs.getString("gfirst_name"), rs.getString("glast_name")));
		guardianShip.setRelation(new PersonRelation(rs.getInt("relation_id"), rs.getString("relation_name")));
		guardianShip.setStudent(new Student(rs.getLong("student_user_id"), rs.getString("sfirst_name"), rs.getString("slast_name")));
		return guardianShip;
	};

	public List<GuardianShip> getGuardianShipsByStudentId(Long studentId) {
		return jdbcTemplateUtil.queryList(GET_STUDENT_GUARDIAN_BY_STUDENT_ID, rowMapper, studentId);
	}

	public List<GuardianShip> getGuardianShipsByStudentAndGuardianId(Long studentId, Long guardianId) {
		return jdbcTemplateUtil.queryList(GET_STUDENT_GUARDIAN_BY_STUDENT_AND_GUARDIAN_ID, rowMapper, studentId,
				guardianId);
	}

	public List<GuardianShip> getGuardianShipsByGuardianId(Long id) {
		return jdbcTemplateUtil.queryList(GET_STUDENT_GUARDIAN_BY_GUARDIAN_ID, rowMapper, id);
	}
}
