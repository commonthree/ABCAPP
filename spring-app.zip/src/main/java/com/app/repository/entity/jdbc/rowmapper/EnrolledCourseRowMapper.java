package com.app.repository.entity.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.app.repository.entity.Course;

public class EnrolledCourseRowMapper implements RowMapper<Course> {

	@Override
	public Course mapRow(ResultSet rs, int rowNum) throws SQLException {
		Course course = new CourseRowMapper().mapRow(rs, rowNum);
		course.setEnrolled(rs.getBoolean("enrolled"));
		return course;
	}

}
