package com.app.repository.entity;

import java.util.ArrayList;
import java.util.List;

public class Course {
	private Long id;
	private String title;
	private String key;
	private Boolean enrolled;
	private Long sessionId;

	private List<Alphabeta> alphabetaList;
	private List<Number> numberList;

	public Course() {
		super();
	}

	public Course(long id) {
		this.id = id;
	}

	public Course(Long id, String title, String key) {
		this(id);
		this.title = title;
		this.key = key;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Alphabeta> getAlphabetaList() {
		if(this.alphabetaList == null)
			this.alphabetaList = new ArrayList<>();
		return alphabetaList;
	}

	public void setAlphabetaList(List<Alphabeta> alphabetaList) {
		this.alphabetaList = alphabetaList;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public List<Number> getNumberList() {
		if(this.numberList == null)
			this.numberList = new ArrayList<>();
		return numberList;
	}

	public void setNumberList(List<Number> numberList) {
		this.numberList = numberList;
	}

	public Boolean getEnrolled() {
		return enrolled;
	}

	public void setEnrolled(Boolean enrolled) {
		this.enrolled = enrolled;
	}

	public Long getSessionId() {
		return sessionId;
	}

	public void setSessionId(Long sessionId) {
		this.sessionId = sessionId;
	}

}
