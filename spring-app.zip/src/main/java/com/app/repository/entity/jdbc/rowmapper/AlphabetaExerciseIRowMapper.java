package com.app.repository.entity.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.app.model.AlphabetaExerciseI;

public class AlphabetaExerciseIRowMapper implements RowMapper<AlphabetaExerciseI> {

	@Override
	public AlphabetaExerciseI mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new AlphabetaExerciseI(rs.getLong("session_id"), rs.getInt("course_id"), rs.getLong("student_id"), rs.getString("exercise"));
	}

}
