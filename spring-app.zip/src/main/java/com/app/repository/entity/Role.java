package com.app.repository.entity;

public enum Role {
	SUPER_ADMIN("Super Admin"), 
	ADMIN("Admin"), 
	TEACHER("Teacher"), 
	GUARDIAN("Guardian"),
	STUDENT("Student");

	private String name;

	Role(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
