package com.app.repository.entity;

public enum MediaType {
	VIDEO, AUDIO, IMAGE
}
