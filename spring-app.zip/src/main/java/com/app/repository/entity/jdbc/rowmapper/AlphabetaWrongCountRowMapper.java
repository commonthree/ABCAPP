package com.app.repository.entity.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.app.repository.entity.Alphabeta;

public class AlphabetaWrongCountRowMapper implements RowMapper<Alphabeta> {

	@Override
	public Alphabeta mapRow(ResultSet rs, int rowNum) throws SQLException {
		Alphabeta a = new AlphabetaStatusRowMapper().mapRow(rs, rowNum);
		a.setWrongCount(rs.getInt("wrong_count"));
		return a;
	}

}
