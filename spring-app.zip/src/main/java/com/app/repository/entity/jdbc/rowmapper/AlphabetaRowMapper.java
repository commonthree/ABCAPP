package com.app.repository.entity.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.app.repository.entity.Alphabeta;
import com.app.repository.entity.Course;

public class AlphabetaRowMapper implements RowMapper<Alphabeta> {

	@Override
	public Alphabeta mapRow(ResultSet rs, int rowNum) throws SQLException {
		Alphabeta alphabeta = new Alphabeta(rs.getInt("character_ascii"), rs.getString("language_code"),
				rs.getString("char_case"), rs.getString("image_cover"), rs.getString("narration_audio_file_name"));
		alphabeta.setCourse(new Course(rs.getLong("course_id")));
		return alphabeta;
	}

}
