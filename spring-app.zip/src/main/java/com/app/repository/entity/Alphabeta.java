package com.app.repository.entity;

public class Alphabeta {
	private static final String CHARACTER_CASE_CAPITAL = "CAPITAL";
	private static final String CHARACTER_CASE_SMALL = "SMALL";
	private Integer characterAscii;
	private Character character;
	private Course course;
	private String languageCode;
	private String characterCase;
	private String imageCover;
	private String narrationAudioFile;
	private String status;
	private int wrongCount;

	public Alphabeta() {
	}

	public Alphabeta(Integer characterAscii, String languageCode, String characterCase, String imageCover,
			String narrationAudioFile) {
		super();
		this.characterAscii = characterAscii;
		this.languageCode = languageCode;
		this.characterCase = characterCase;
		if(imageCover != null && !imageCover.isBlank()) {
			this.imageCover = imageCover;			
		} else {
			this.imageCover = "/img/200/" + Character.toString(this.characterAscii).toLowerCase().concat(".png");
		}
		this.narrationAudioFile = narrationAudioFile;
	}

	public Alphabeta(int c) {
		super();
		this.characterAscii = c;
	}

	public Integer getCharacterAscii() {
		return characterAscii;
	}

	public void setCharacterAscii(Integer characterAscii) {
		this.characterAscii = characterAscii;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getCharacterCase() {
		return characterCase;
	}

	public void setCharacterCase(String characterCase) {
		this.characterCase = characterCase;
	}

	public String getImageCover() {
		return imageCover;
	}

	public void setImageCover(String imageCover) {
		this.imageCover = imageCover;
	}

	public String getNarrationAudioFile() {
		return narrationAudioFile;
	}

	public void setNarrationAudioFile(String narrationAudioFile) {
		this.narrationAudioFile = narrationAudioFile;
	}

	public Character getCharacter() {
		if(this.characterAscii != null) {
			this.character = Character.valueOf((char) this.characterAscii.intValue());
			if(this.characterCase != null) {
				if(this.characterCase.equals(CHARACTER_CASE_CAPITAL)) {
					this.character = Character.toUpperCase(this.character);
				} else {
					this.character = Character.toLowerCase(this.character);					
				}
			}
		}
		return character;
	}

	public void setCharacter(Character character) {
		this.character = character;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getWrongCount() {
		return wrongCount;
	}

	public void setWrongCount(int wrongCount) {
		this.wrongCount = wrongCount;
	}

}
