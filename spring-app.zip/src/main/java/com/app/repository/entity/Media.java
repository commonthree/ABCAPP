package com.app.repository.entity;

public class Media {
	private String id;
	private String fileName;
	private String path;
	private MediaType type;
	private String extension;

	public Media() {
	}

	public Media(String fileName, String path, MediaType type, String extension) {
		super();
		this.fileName = fileName;
		this.path = path;
		this.type = type;
		this.extension = extension;
	}

	public Media(String id, String fileName, String path, MediaType type, String extension) {
		super();
		this.id = id;
		this.fileName = fileName;
		this.path = path;
		this.type = type;
		this.extension = extension;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public MediaType getType() {
		return type;
	}

	public void setType(MediaType type) {
		this.type = type;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

}
