package com.app.repository.entity.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.app.repository.entity.Alphabeta;

public class AlphabetaStatusRowMapper implements RowMapper<Alphabeta> {

	@Override
	public Alphabeta mapRow(ResultSet rs, int rowNum) throws SQLException {
		Alphabeta alphabeta = new AlphabetaRowMapper().mapRow(rs, rowNum);
		alphabeta.setStatus(rs.getString("status"));
		return alphabeta;
	}

}
