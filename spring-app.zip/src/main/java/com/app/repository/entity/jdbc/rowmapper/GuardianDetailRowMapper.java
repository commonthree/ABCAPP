package com.app.repository.entity.jdbc.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.app.model.Guardian;

public class GuardianDetailRowMapper implements RowMapper<Guardian> {

	@Override
	public Guardian mapRow(ResultSet rs, int rowNum) throws SQLException {
		Guardian guardian = new Guardian();
		guardian.setId(rs.getLong("id"));
		guardian.setFirstName(rs.getString("first_name"));
		guardian.setLastName(rs.getString("last_name"));
		guardian.setUsername(rs.getString("username"));
		guardian.setEmail(rs.getString("email"));
		guardian.setActive(rs.getBoolean("active"));
		return guardian;
	}
}
