package com.app.repository.util;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import com.app.model.Page;
import com.app.model.Student;

@Service
public class JdbcTemplateUtil {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public <T> List<T> queryList(String query, RowMapper<T> rowMapper, Object... args) {
		return jdbcTemplate.query(query, rowMapper, args);
	}

	public <T> T queryOne(String query, RowMapper<T> rowMapper, Object... args) {
		List<T> list = jdbcTemplate.query(query, rowMapper, args);
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}

	public int updateAndGetUpdateCount(String query, Object... args) {
		return jdbcTemplate.update(con -> {
			PreparedStatement prepareStatement = con.prepareStatement(query);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					prepareStatement.setObject(i + 1, args[i]);
				}
			}
			return prepareStatement;
		});
	}

	public Number updateAndGetId(String query, Object... args) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(con -> {
			PreparedStatement prepareStatement = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					prepareStatement.setObject(i + 1, args[i]);
				}
			}
			return prepareStatement;
		}, keyHolder);
		return keyHolder.getKey();
	}

	public int queryCount(String query, Object... args) {
		List<Integer> counts = jdbcTemplate.query(String.format("select count(*) as _count from (%s) as t", query),
				(PreparedStatementSetter) ps -> {
					for (int i = 0; i < args.length; i++) {
						ps.setObject(i + 1, args[i]);
					}
				}, (RowMapper<Integer>) (rs, rowNum) -> rs.getInt("_count"));
		if (counts != null) {
			return counts.get(0);
		}
		return 0;
	}

	public <T> List<T> queryPage(String query, RowMapper<T> rowMapper, Page<T> page, Object... args) {
		return jdbcTemplate.query(String.format("%s limit ?, ?", query),
				(PreparedStatementSetter) ps -> {
					int i = 0;
					if(args != null) {
						for (;i < args.length; i++) {
							ps.setObject(i+1, args[i]);
						}						
					}
					ps.setInt(++i, (page.getNumber() - 1) * page.getSize()); // page offset index
					ps.setInt(++i, page.getSize());
				}, rowMapper);
	}

}
