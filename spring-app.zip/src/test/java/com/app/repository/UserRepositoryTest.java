package com.app.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.app.model.Page;
import com.app.model.Student;
import com.app.repository.entity.Role;

@SpringBootTest
class UserRepositoryTest {

	@Autowired
	private UserRepository userRepository;

	@Test
	void studentsPage_test() {
		Page<Student> page = new Page<>(1, 10);
		Page<Student> studentPage = this.userRepository.getUsersByRoles(Role.STUDENT, page);
		assertNotNull(studentPage);
		assertEquals(page.getNumber(), studentPage.getNumber());
		assertFalse(studentPage.getItems().isEmpty());
	}

}
