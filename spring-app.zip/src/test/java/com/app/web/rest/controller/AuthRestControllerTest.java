package com.app.web.rest.controller;

import java.nio.charset.Charset;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.app.web.model.AuthRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class AuthRestControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void authenticateSuccess() throws Exception {
		MediaType mediaTypeJsonUtf8 = new MediaType(MediaType.APPLICATION_JSON, Charset.forName("UTF-8"));
		AuthRequest authRequest = new AuthRequest();
		authRequest.setEmail("jeevanaawara@gmail.com");
		authRequest.setPassword("passw0rd1");
		mockMvc.perform(MockMvcRequestBuilders.post("/auth/authenticate")
				.content(objectMapper.writeValueAsString(authRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	public void authenticateFailure() throws Exception {
		MediaType mediaTypeJsonUtf8 = new MediaType(MediaType.APPLICATION_JSON, Charset.forName("UTF-8"));
		AuthRequest authRequest = new AuthRequest();
		authRequest.setEmail("jeevanaawara@gmail.com");
		authRequest.setPassword("passw0rd");
		mockMvc.perform(MockMvcRequestBuilders.post("/auth/authenticate")
				.content(objectMapper.writeValueAsString(authRequest)).contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isUnauthorized());
	}
	
	@Test
	public void registerSuccess() throws Exception {
		MediaType mediaTypeJsonUtf8 = new MediaType(MediaType.APPLICATION_JSON, Charset.forName("UTF-8"));
		AuthRequest authRequest = new AuthRequest();
		authRequest.setEmail(String.format("jeevanaawara@gmail.com"));
		authRequest.setPassword("passw0rd");
		mockMvc.perform(MockMvcRequestBuilders.post("/auth/authenticate")
				.content(objectMapper.writeValueAsString(authRequest)).contentType(MediaType.APPLICATION_JSON))
		.andExpect(MockMvcResultMatchers.status().isUnauthorized());
	}

}
